#include <M5Cardputer.h>
#include <WiFi.h>
#include <WebSocketsClient.h>
#include <ArduinoJson.h>
#include <HTTPClient.h>
#include <SD.h>
#include <FS.h>

// Настройки дисплея
#define SCREEN_WIDTH 240
#define SCREEN_HEIGHT 135

// Настройки SD карты
#define SD_CS_PIN 4
#define SD_MOSI_PIN 14
#define SD_MISO_PIN 39
#define SD_SCK_PIN 40

// Режимы работы
enum CardputerMode {
    MODE_LOGIN,
    MODE_CHAT,
    MODE_BLOG,
    MODE_SERVER,
    MODE_SUPPORT,
    MODE_FILE_BROWSER
};

// Состояния ввода
enum InputState {
    INPUT_NORMAL,
    INPUT_MESSAGE,
    INPUT_SUPPORT,
    INPUT_FILE_VIEW
};

// Глобальные объекты
WebSocketsClient webSocket;
HTTPClient http;

// Переменные состояния
CardputerMode currentMode = MODE_LOGIN;
InputState inputState = INPUT_NORMAL;
String currentUser = "";
bool isLoggedIn = false;
bool isServerConnected = false;
bool sdCardReady = false;

String mainServerIP = "";
std::vector<String> chatMessages;
std::vector<String> blogPosts;
std::vector<String> supportTickets;
std::vector<String> fileList;

String currentMessage = "";
String currentFilePath = "";
int scrollPosition = 0;
int selectedItem = 0;

// Переменные интерфейса
unsigned long lastKeyPress = 0;
unsigned long lastScreenUpdate = 0;
const unsigned long DEBOUNCE_DELAY = 200;
const unsigned long SCREEN_UPDATE_INTERVAL = 1000;

// Серверная статистика
struct ServerStats {
    int connectedUsers;
    float cpuUsage;
    float memoryUsage;
    int activeServers;
    float sdUsage;
    String status;
};

ServerStats serverStats;

void setup() {
    M5Cardputer.begin();
    Serial.begin(115200);
    Serial.println("M5Cardputer Chat Client starting...");
    
    // Инициализация дисплея
    M5Cardputer.Display.setRotation(1);
    M5Cardputer.Display.fillScreen(BLACK);
    M5Cardputer.Display.setTextSize(1);
    M5Cardputer.Display.setTextColor(WHITE);
    
    // Инициализация SD карты (обязательно!)
    if (!SD.begin(SD_CS_PIN)) {
        Serial.println("SD Card initialization failed!");
        M5Cardputer.Display.setCursor(10, 10);
        M5Cardputer.Display.setTextColor(RED);
        M5Cardputer.Display.println("SD ERROR!");
        M5Cardputer.Display.println("Need 2GB+ SD card");
        while(1) {
            delay(1000);
        }
    }
    
    // Проверяем размер SD карты
    uint64_t cardSize = SD.cardSize() / (1024 * 1024);
    Serial.printf("SD Card Size: %lluMB\n", cardSize);
    
    if (cardSize < 2048) {
        Serial.println("SD Card too small! Need at least 2GB");
        M5Cardputer.Display.setCursor(10, 30);
        M5Cardputer.Display.setTextColor(RED);
        M5Cardputer.Display.println("SD too small!");
        M5Cardputer.Display.println("Need 2GB+");
        while(1) {
            delay(1000);
        }
    }
    
    sdCardReady = true;
    
    // Создаем файловую структуру на SD карте
    createSDStructure();
    
    // Поиск и подключение к серверу
    searchForServer();
    
    // Показать начальный экран
    showLoginScreen();
    
    Serial.println("M5Cardputer initialized successfully");
}

void createSDStructure() {
    // Создаем необходимые директории на SD карте
    SD.mkdir("/root");
    SD.mkdir("/root/users");
    SD.mkdir("/root/chat");
    SD.mkdir("/root/chat/files");
    SD.mkdir("/root/chat/images");
    SD.mkdir("/root/chat/audio");
    SD.mkdir("/root/blog");
    SD.mkdir("/root/support");
    SD.mkdir("/root/logs");
    SD.mkdir("/root/config");
    SD.mkdir("/root/files");
    SD.mkdir("/root/temp");
    
    // Создаем файл конфигурации если его нет
    if (!SD.exists("/root/config/cardputer.conf")) {
        File configFile = SD.open("/root/config/cardputer.conf", FILE_WRITE);
        if (configFile) {
            configFile.println("# M5Cardputer Configuration");
            configFile.println("device_type=cardputer");
            configFile.println("server_mode=true");
            configFile.println("auto_sync=true");
            configFile.close();
        }
    }
}

void searchForServer() {
    M5Cardputer.Display.fillScreen(BLACK);
    M5Cardputer.Display.setCursor(10, 10);
    M5Cardputer.Display.setTextColor(CYAN);
    M5Cardputer.Display.println("Поиск сервера...");
    
    // Сканируем WiFi сети
    int networksFound = WiFi.scanNetworks();
    
    for (int i = 0; i < networksFound; i++) {
        String ssid = WiFi.SSID(i);
        if (ssid.startsWith("ESP32-ChatServer") || ssid.startsWith("ESP32-")) {
            M5Cardputer.Display.setCursor(10, 30 + (i * 10));
            M5Cardputer.Display.printf("Найден: %s", ssid.c_str());
            
            // Пытаемся подключиться
            WiFi.begin(ssid.c_str(), "12345678");
            
            int attempts = 0;
            while (WiFi.status() != WL_CONNECTED && attempts < 20) {
                delay(500);
                attempts++;
            }
            
            if (WiFi.status() == WL_CONNECTED) {
                mainServerIP = WiFi.gatewayIP().toString();
                isServerConnected = true;
                
                M5Cardputer.Display.setCursor(10, 80);
                M5Cardputer.Display.setTextColor(GREEN);
                M5Cardputer.Display.printf("Подключено: %s", mainServerIP.c_str());
                
                // Подключаемся к WebSocket
                connectWebSocket();
                break;
            }
        }
    }
    
    if (!isServerConnected) {
        M5Cardputer.Display.setCursor(10, 100);
        M5Cardputer.Display.setTextColor(RED);
        M5Cardputer.Display.println("Сервер не найден!");
        M5Cardputer.Display.println("Автономный режим");
        
        // Запускаем собственный сервер
        startAutonomousMode();
    }
    
    delay(2000);
}

void startAutonomousMode() {
    // В автономном режиме M5Cardputer становится сервером
    WiFi.mode(WIFI_AP);
    WiFi.softAP("ESP32-Cardputer", "12345678");
    
    IPAddress IP = WiFi.softAPIP();
    Serial.print("Cardputer AP IP: ");
    Serial.println(IP);
    
    // Записываем в логи
    logToSD("Cardputer started in autonomous mode. IP: " + IP.toString());
}

void connectWebSocket() {
    webSocket.begin(mainServerIP, 81, "/");
    webSocket.onEvent(webSocketEvent);
    webSocket.setReconnectInterval(5000);
}

void webSocketEvent(WStype_t type, uint8_t * payload, size_t length) {
    switch(type) {
        case WStype_DISCONNECTED:
            Serial.println("WebSocket Disconnected");
            isServerConnected = false;
            break;
            
        case WStype_CONNECTED:
            Serial.printf("WebSocket Connected to: %s\n", payload);
            isServerConnected = true;
            break;
            
        case WStype_TEXT: {
            String message = String((char*)payload);
            DynamicJsonDocument doc(1024);
            deserializeJson(doc, message);
            
            handleWebSocketMessage(doc);
            break;
        }
        
        default:
            break;
    }
}

void handleWebSocketMessage(DynamicJsonDocument& doc) {
    String msgType = doc["type"];
    
    if (msgType == "new_message") {
        String username = doc["username"];
        String content = doc["content"];
        String messageType = doc["messageType"];
        
        String fullMessage = username + ": " + content;
        chatMessages.push_back(fullMessage);
        
        // Сохраняем на SD карту
        saveChatMessageToSD(username, content, messageType);
        
        // Ограничиваем количество сообщений в памяти
        if (chatMessages.size() > 50) {
            chatMessages.erase(chatMessages.begin());
        }
        
        // Обновляем экран если находимся в чате
        if (currentMode == MODE_CHAT) {
            showChatScreen();
        }
    }
}

void showLoginScreen() {
    M5Cardputer.Display.fillScreen(BLACK);
    M5Cardputer.Display.setCursor(10, 10);
    M5Cardputer.Display.setTextColor(CYAN);
    M5Cardputer.Display.setTextSize(2);
    M5Cardputer.Display.println("Cardputer Chat");
    
    M5Cardputer.Display.setTextSize(1);
    M5Cardputer.Display.setTextColor(WHITE);
    M5Cardputer.Display.setCursor(10, 40);
    M5Cardputer.Display.println("Для входа используйте");
    M5Cardputer.Display.println("веб-интерфейс:");
    M5Cardputer.Display.println(mainServerIP);
    
    M5Cardputer.Display.setCursor(10, 80);
    M5Cardputer.Display.setTextColor(YELLOW);
    M5Cardputer.Display.println("После входа:");
    M5Cardputer.Display.println("G0 - Переключение режимов");
    M5Cardputer.Display.println("1 - Написать сообщение");
    M5Cardputer.Display.println("2 - Отправить файл");
    M5Cardputer.Display.println("3 - Запись аудио");
    M5Cardputer.Display.println("4 - Файловый браузер");
    M5Cardputer.Display.println("ESC - Выход/Отмена");
}

void showChatScreen() {
    M5Cardputer.Display.fillScreen(BLACK);
    M5Cardputer.Display.setCursor(5, 5);
    M5Cardputer.Display.setTextColor(CYAN);
    M5Cardputer.Display.println("=== ЧАТ ===");
    
    // Показываем последние сообщения
    int startY = 20;
    int maxMessages = min(8, (int)chatMessages.size());
    int startIndex = max(0, (int)chatMessages.size() - maxMessages - scrollPosition);
    
    for (int i = startIndex; i < min(startIndex + 8, (int)chatMessages.size()); i++) {
        M5Cardputer.Display.setCursor(5, startY + (i - startIndex) * 12);
        M5Cardputer.Display.setTextColor(WHITE);
        
        String msg = chatMessages[i];
        if (msg.length() > 38) {
            msg = msg.substring(0, 35) + "...";
        }
        M5Cardputer.Display.println(msg);
    }
    
    // Статус ввода
    M5Cardputer.Display.setCursor(5, 120);
    if (inputState == INPUT_MESSAGE) {
        M5Cardputer.Display.setTextColor(GREEN);
        M5Cardputer.Display.println(">> " + currentMessage + "_");
    } else {
        M5Cardputer.Display.setTextColor(YELLOW);
        M5Cardputer.Display.println("1-Сообщ 2-Файл 3-Аудио G0-Режим");
    }
}

void showBlogScreen() {
    M5Cardputer.Display.fillScreen(BLACK);
    M5Cardputer.Display.setCursor(5, 5);
    M5Cardputer.Display.setTextColor(MAGENTA);
    M5Cardputer.Display.println("=== БЛОГ ===");
    
    if (blogPosts.empty()) {
        M5Cardputer.Display.setCursor(10, 40);
        M5Cardputer.Display.setTextColor(YELLOW);
        M5Cardputer.Display.println("Постов пока нет");
    } else {
        int startY = 20;
        int maxPosts = min(7, (int)blogPosts.size());
        int startIndex = max(0, (int)blogPosts.size() - maxPosts - scrollPosition);
        
        for (int i = startIndex; i < min(startIndex + 7, (int)blogPosts.size()); i++) {
            M5Cardputer.Display.setCursor(5, startY + (i - startIndex) * 15);
            M5Cardputer.Display.setTextColor(WHITE);
            
            String post = blogPosts[i];
            if (post.length() > 35) {
                post = post.substring(0, 32) + "...";
            }
            M5Cardputer.Display.println(post);
        }
    }
    
    M5Cardputer.Display.setCursor(5, 120);
    M5Cardputer.Display.setTextColor(GREEN);
    M5Cardputer.Display.println("G0 - Режим  UP/DOWN - Прокрутка");
}

void showServerScreen() {
    M5Cardputer.Display.fillScreen(BLACK);
    M5Cardputer.Display.setCursor(5, 5);
    M5Cardputer.Display.setTextColor(GREEN);
    M5Cardputer.Display.println("=== СЕРВЕР ===");
    
    if (isServerConnected) {
        M5Cardputer.Display.setCursor(5, 20);
        M5Cardputer.Display.setTextColor(WHITE);
        M5Cardputer.Display.printf("IP: %s\n", mainServerIP.c_str());
        
        M5Cardputer.Display.setCursor(5, 35);
        M5Cardputer.Display.printf("Польз: %d\n", serverStats.connectedUsers);
        
        M5Cardputer.Display.setCursor(5, 50);
        M5Cardputer.Display.printf("CPU: %.1f%%\n", serverStats.cpuUsage);
        
        M5Cardputer.Display.setCursor(5, 65);
        M5Cardputer.Display.printf("RAM: %.1f%%\n", serverStats.memoryUsage);
        
        M5Cardputer.Display.setCursor(5, 80);
        M5Cardputer.Display.printf("SD: %.1f%%\n", serverStats.sdUsage);
        
        M5Cardputer.Display.setCursor(5, 95);
        M5Cardputer.Display.printf("Серверов: %d\n", serverStats.activeServers);
        
        M5Cardputer.Display.setCursor(5, 110);
        M5Cardputer.Display.setTextColor(CYAN);
        M5Cardputer.Display.println("Статус: Активен");
    } else {
        M5Cardputer.Display.setCursor(5, 40);
        M5Cardputer.Display.setTextColor(RED);
        M5Cardputer.Display.println("Поиск серверов...");
        
        M5Cardputer.Display.setCursor(5, 60);
        M5Cardputer.Display.setTextColor(YELLOW);
        M5Cardputer.Display.println("Автономный режим");
        
        M5Cardputer.Display.setCursor(5, 80);
        M5Cardputer.Display.printf("SD: %.1f%%", serverStats.sdUsage);
    }
    
    M5Cardputer.Display.setCursor(5, 125);
    M5Cardputer.Display.setTextColor(GREEN);
    M5Cardputer.Display.println("G0 - След. режим");
}

void showSupportScreen() {
    M5Cardputer.Display.fillScreen(BLACK);
    M5Cardputer.Display.setCursor(5, 5);
    M5Cardputer.Display.setTextColor(ORANGE);
    M5Cardputer.Display.println("=== ПОДДЕРЖКА ===");
    
    M5Cardputer.Display.setCursor(5, 25);
    M5Cardputer.Display.setTextColor(WHITE);
    M5Cardputer.Display.println("Отправка сообщения админу");
    
    if (inputState == INPUT_SUPPORT) {
        M5Cardputer.Display.setCursor(5, 50);
        M5Cardputer.Display.setTextColor(GREEN);
        M5Cardputer.Display.println("Вопрос:");
        M5Cardputer.Display.setCursor(5, 70);
        M5Cardputer.Display.println(currentMessage + "_");
        
        M5Cardputer.Display.setCursor(5, 110);
        M5Cardputer.Display.setTextColor(YELLOW);
        M5Cardputer.Display.println("ENTER - Отправить");
        M5Cardputer.Display.println("ESC - Отмена");
    } else {
        M5Cardputer.Display.setCursor(5, 50);
        M5Cardputer.Display.setTextColor(YELLOW);
        M5Cardputer.Display.println("1 - Написать обращение");
        M5Cardputer.Display.println("G0 - Другой режим");
    }
}

void showFileBrowserScreen() {
    M5Cardputer.Display.fillScreen(BLACK);
    M5Cardputer.Display.setCursor(5, 5);
    M5Cardputer.Display.setTextColor(BLUE);
    M5Cardputer.Display.println("=== ФАЙЛЫ ===");
    
    if (fileList.empty()) {
        refreshFileList();
    }
    
    if (inputState == INPUT_FILE_VIEW && !currentFilePath.isEmpty()) {
        // Показываем содержимое файла
        showFileContent();
    } else {
        // Показываем список файлов
        int startY = 20;
        int maxFiles = min(7, (int)fileList.size());
        int startIndex = max(0, scrollPosition);
        
        for (int i = startIndex; i < min(startIndex + 7, (int)fileList.size()); i++) {
            M5Cardputer.Display.setCursor(5, startY + (i - startIndex) * 12);
            
            if (i == selectedItem) {
                M5Cardputer.Display.setTextColor(BLACK);
                M5Cardputer.Display.fillRect(0, startY + (i - startIndex) * 12 - 2, 240, 12, WHITE);
            } else {
                M5Cardputer.Display.setTextColor(WHITE);
            }
            
            String fileName = fileList[i];
            if (fileName.length() > 35) {
                fileName = fileName.substring(0, 32) + "...";
            }
            M5Cardputer.Display.println(fileName);
        }
        
        M5Cardputer.Display.setCursor(5, 120);
        M5Cardputer.Display.setTextColor(GREEN);
        M5Cardputer.Display.println("UP/DOWN-Навиг ENTER-Открыть");
    }
}

void showFileContent() {
    M5Cardputer.Display.fillScreen(BLACK);
    M5Cardputer.Display.setCursor(5, 5);
    M5Cardputer.Display.setTextColor(CYAN);
    M5Cardputer.Display.println("=== ПРОСМОТР ФАЙЛА ===");
    
    // Показываем имя файла
    M5Cardputer.Display.setCursor(5, 20);
    M5Cardputer.Display.setTextColor(YELLOW);
    String shortName = currentFilePath;
    if (shortName.length() > 30) {
        shortName = "..." + shortName.substring(shortName.length() - 27);
    }
    M5Cardputer.Display.println(shortName);
    
    // Читаем и показываем содержимое
    if (SD.exists(currentFilePath)) {
        File file = SD.open(currentFilePath);
        if (file) {
            int lineY = 40;
            int lineCount = 0;
            
            while (file.available() && lineCount < 6) {
                String line = file.readStringUntil('\n');
                line.trim();
                
                if (line.length() > 38) {
                    line = line.substring(0, 35) + "...";
                }
                
                M5Cardputer.Display.setCursor(5, lineY + (lineCount * 12));
                M5Cardputer.Display.setTextColor(WHITE);
                M5Cardputer.Display.println(line);
                lineCount++;
            }
            
            file.close();
        }
    }
    
    M5Cardputer.Display.setCursor(5, 120);
    M5Cardputer.Display.setTextColor(GREEN);
    M5Cardputer.Display.println("ESC - Назад");
}

void refreshFileList() {
    fileList.clear();
    
    // Сканируем файлы на SD карте
    File root = SD.open("/root");
    scanDirectory(root, "/root", 0);
    root.close();
}

void scanDirectory(File dir, String path, int level) {
    if (level > 3) return; // Ограничиваем глубину
    
    File file = dir.openNextFile();
    while (file) {
        String fullPath = path + "/" + file.name();
        
        if (file.isDirectory()) {
            fileList.push_back("[DIR] " + String(file.name()));
            
            if (level < 2) {
                File subdir = SD.open(fullPath);
                scanDirectory(subdir, fullPath, level + 1);
                subdir.close();
            }
        } else {
            fileList.push_back(String(file.name()) + " (" + String(file.size()) + "b)");
        }
        
        file = dir.openNextFile();
    }
}

void handleKeyboard() {
    M5Cardputer.update();
    
    if (M5Cardputer.Keyboard.isChange()) {
        if (M5Cardputer.Keyboard.isPressed()) {
            Keyboard_Class::KeysState status = M5Cardputer.Keyboard.keysState();
            
            // Обработка специальных клавиш
            if (status.g0) {
                handleG0Press();
            }
            else if (status.enter) {
                handleEnterPress();
            }
            else if (status.esc) {
                handleEscPress();
            }
            else if (status.del) {
                handleDeletePress();
            }
            else if (status.fn) {
                // Функциональные клавиши
            }
            
            // Обработка цифровых клавиш в обычном режиме
            if (inputState == INPUT_NORMAL) {
                for (auto i : status.hid_keys) {
                    switch (i) {
                        case 0x1E: // 1
                            startMessageInput();
                            break;
                        case 0x1F: // 2
                            sendFileFromSD();
                            break;
                        case 0x20: // 3
                            startAudioRecording();
                            break;
                        case 0x21: // 4
                            currentMode = MODE_FILE_BROWSER;
                            refreshFileList();
                            showFileBrowserScreen();
                            break;
                    }
                }
            }
            
            // Обработка текстового ввода
            if (inputState == INPUT_MESSAGE || inputState == INPUT_SUPPORT) {
                String keyStr = M5Cardputer.Keyboard.getKeyValue();
                if (keyStr.length() > 0) {
                    currentMessage += keyStr;
                    
                    // Ограничиваем длину сообщения
                    if (currentMessage.length() > 100) {
                        currentMessage = currentMessage.substring(0, 100);
                    }
                    
                    // Обновляем экран
                    if (currentMode == MODE_CHAT) {
                        showChatScreen();
                    } else if (currentMode == MODE_SUPPORT) {
                        showSupportScreen();
                    }
                }
            }
            
            // Навигация в файловом браузере
            if (currentMode == MODE_FILE_BROWSER && inputState != INPUT_FILE_VIEW) {
                for (auto i : status.hid_keys) {
                    if (i == 0x52) { // UP arrow
                        if (selectedItem > 0) {
                            selectedItem--;
                            if (selectedItem < scrollPosition) {
                                scrollPosition = selectedItem;
                            }
                            showFileBrowserScreen();
                        }
                    } else if (i == 0x51) { // DOWN arrow
                        if (selectedItem < fileList.size() - 1) {
                            selectedItem++;
                            if (selectedItem >= scrollPosition + 7) {
                                scrollPosition = selectedItem - 6;
                            }
                            showFileBrowserScreen();
                        }
                    }
                }
            }
        }
    }
}

void handleG0Press() {
    if (millis() - lastKeyPress < DEBOUNCE_DELAY) return;
    lastKeyPress = millis();
    
    // Переключение режимов
    switch (currentMode) {
        case MODE_CHAT:
            currentMode = MODE_BLOG;
            loadBlogPosts();
            showBlogScreen();
            break;
        case MODE_BLOG:
            currentMode = MODE_SERVER;
            updateServerStats();
            showServerScreen();
            break;
        case MODE_SERVER:
            currentMode = MODE_SUPPORT;
            showSupportScreen();
            break;
        case MODE_SUPPORT:
            currentMode = MODE_FILE_BROWSER;
            refreshFileList();
            showFileBrowserScreen();
            break;
        case MODE_FILE_BROWSER:
            currentMode = MODE_CHAT;
            loadChatHistory();
            showChatScreen();
            break;
        default:
            currentMode = MODE_CHAT;
            break;
    }
    
    inputState = INPUT_NORMAL;
    currentMessage = "";
    scrollPosition = 0;
    selectedItem = 0;
}

void handleEnterPress() {
    if (millis() - lastKeyPress < DEBOUNCE_DELAY) return;
    lastKeyPress = millis();
    
    if (inputState == INPUT_MESSAGE && !currentMessage.isEmpty()) {
        sendChatMessage(currentMessage);
        currentMessage = "";
        inputState = INPUT_NORMAL;
        showChatScreen();
    }
    else if (inputState == INPUT_SUPPORT && !currentMessage.isEmpty()) {
        sendSupportMessage(currentMessage);
        currentMessage = "";
        inputState = INPUT_NORMAL;
        showSupportScreen();
    }
    else if (currentMode == MODE_FILE_BROWSER && inputState != INPUT_FILE_VIEW) {
        // Открываем выбранный файл
        if (selectedItem < fileList.size()) {
            String selectedFile = fileList[selectedItem];
            if (!selectedFile.startsWith("[DIR]")) {
                // Это файл, открываем его
                String fileName = selectedFile;
                int spaceIndex = fileName.indexOf(" (");
                if (spaceIndex > 0) {
                    fileName = fileName.substring(0, spaceIndex);
                }
                
                currentFilePath = "/root/" + fileName; // Упрощенно
                inputState = INPUT_FILE_VIEW;
                showFileContent();
            }
        }
    }
}

void handleEscPress() {
    if (millis() - lastKeyPress < DEBOUNCE_DELAY) return;
    lastKeyPress = millis();
    
    if (inputState == INPUT_MESSAGE || inputState == INPUT_SUPPORT) {
        inputState = INPUT_NORMAL;
        currentMessage = "";
        
        if (currentMode == MODE_CHAT) {
            showChatScreen();
        } else if (currentMode == MODE_SUPPORT) {
            showSupportScreen();
        }
    }
    else if (inputState == INPUT_FILE_VIEW) {
        inputState = INPUT_NORMAL;
        currentFilePath = "";
        showFileBrowserScreen();
    }
}

void handleDeletePress() {
    if ((inputState == INPUT_MESSAGE || inputState == INPUT_SUPPORT) && !currentMessage.isEmpty()) {
        currentMessage.remove(currentMessage.length() - 1);
        
        if (currentMode == MODE_CHAT) {
            showChatScreen();
        } else if (currentMode == MODE_SUPPORT) {
            showSupportScreen();
        }
    }
}

void startMessageInput() {
    if (currentMode == MODE_CHAT) {
        inputState = INPUT_MESSAGE;
        currentMessage = "";
        showChatScreen();
    } else if (currentMode == MODE_SUPPORT) {
        inputState = INPUT_SUPPORT;
        currentMessage = "";
        showSupportScreen();
    }
}

void sendFileFromSD() {
    // Отправляем уведомление о загрузке файла
    sendChatMessage("[Файл отправлен с SD карты]");
}

void startAudioRecording() {
    // Имитация записи аудио (M5Cardputer не имеет микрофона)
    sendChatMessage("[Аудио сообщение записано]");
}

void sendChatMessage(String message) {
    if (!isServerConnected) {
        // Сохраняем на SD карту для последующей синхронизации
        saveChatMessageToSD(currentUser, message, "text");
        return;
    }
    
    DynamicJsonDocument doc(512);
    doc["type"] = "chat_message";
    doc["username"] = currentUser;
    doc["message"] = message;
    doc["messageType"] = "text";
    
    String jsonString;
    serializeJson(doc, jsonString);
    
    webSocket.sendTXT(jsonString);
    
    // Также сохраняем на SD карту
    saveChatMessageToSD(currentUser, message, "text");
}

void sendSupportMessage(String message) {
    if (isServerConnected) {
        HTTPClient http;
        http.begin("http://" + mainServerIP + "/api/sendSupportMessage");
        http.addHeader("Content-Type", "application/json");
        
        DynamicJsonDocument doc(512);
        doc["username"] = currentUser;
        doc["message"] = message;
        
        String jsonString;
        serializeJson(doc, jsonString);
        
        int httpResponseCode = http.POST(jsonString);
        http.end();
        
        // Показываем подтверждение
        M5Cardputer.Display.fillScreen(BLACK);
        M5Cardputer.Display.setCursor(30, 60);
        M5Cardputer.Display.setTextColor(GREEN);
        M5Cardputer.Display.println("Сообщение отправлено!");
        delay(1500);
    }
    
    // Сохраняем на SD карту
    saveSupportMessageToSD(currentUser, message);
}

void loadChatHistory() {
    if (isServerConnected) {
        HTTPClient http;
        http.begin("http://" + mainServerIP + "/api/getChatHistory");
        
        int httpResponseCode = http.GET();
        
        if (httpResponseCode == 200) {
            String response = http.getString();
            
            DynamicJsonDocument doc(4096);
            deserializeJson(doc, response);
            
            JsonArray messages = doc["messages"];
            chatMessages.clear();
            
            for (JsonObject message : messages) {
                String username = message["username"];
                String content = message["content"];
                String fullMessage = username + ": " + content;
                chatMessages.push_back(fullMessage);
            }
        }
        
        http.end();
    } else {
        // Загружаем из SD карты
        loadChatFromSD();
    }
}

void loadBlogPosts() {
    if (isServerConnected) {
        HTTPClient http;
        http.begin("http://" + mainServerIP + "/api/getBlogPosts");
        
        int httpResponseCode = http.GET();
        
        if (httpResponseCode == 200) {
            String response = http.getString();
            
            DynamicJsonDocument doc(4096);
            deserializeJson(doc, response);
            
            JsonArray posts = doc["posts"];
            blogPosts.clear();
            
            for (JsonObject post : posts) {
                String title = post["title"];
                String author = post["author"];
                String content = post["content"];
                String fullPost = title + " - " + author;
                blogPosts.push_back(fullPost);
            }
        }
        
        http.end();
    } else {
        // Загружаем из SD карты
        loadBlogFromSD();
    }
}

void updateServerStats() {
    if (isServerConnected) {
        HTTPClient http;
        http.begin("http://" + mainServerIP + "/api/getServerStatus");
        
        int httpResponseCode = http.GET();
        
        if (httpResponseCode == 200) {
            String response = http.getString();
            
            DynamicJsonDocument doc(1024);
            deserializeJson(doc, response);
            
            serverStats.connectedUsers = doc["connectedUsers"];
            serverStats.cpuUsage = doc["cpuUsage"];
            serverStats.memoryUsage = doc["memoryUsage"];
            serverStats.activeServers = doc["activeServers"];
        }
        
        http.end();
    }
    
    // Получаем информацию о SD карте
    uint64_t cardSize = SD.cardSize() / (1024 * 1024);
    uint64_t usedSize = SD.usedBytes() / (1024 * 1024);
    serverStats.sdUsage = (float)usedSize / cardSize * 100.0;
}

// Функции работы с SD картой
void saveChatMessageToSD(String username, String content, String messageType) {
    if (!sdCardReady) return;
    
    File chatFile = SD.open("/root/chat/messages.txt", FILE_APPEND);
    if (chatFile) {
        String timestamp = String(millis());
        String line = timestamp + "," + username + "," + messageType + "," + content;
        chatFile.println(line);
        chatFile.close();
    }
}

void saveSupportMessageToSD(String username, String message) {
    if (!sdCardReady) return;
    
    File supportFile = SD.open("/root/support/tickets.txt", FILE_APPEND);
    if (supportFile) {
        String timestamp = String(millis());
        String line = timestamp + "," + username + "," + message;
        supportFile.println(line);
        supportFile.close();
    }
}

void loadChatFromSD() {
    if (!sdCardReady) return;
    
    chatMessages.clear();
    
    if (SD.exists("/root/chat/messages.txt")) {
        File chatFile = SD.open("/root/chat/messages.txt");
        if (chatFile) {
            while (chatFile.available()) {
                String line = chatFile.readStringUntil('\n');
                line.trim();
                
                if (line.length() > 0 && !line.startsWith("#")) {
                    int firstComma = line.indexOf(',');
                    int secondComma = line.indexOf(',', firstComma + 1);
                    int thirdComma = line.indexOf(',', secondComma + 1);
                    
                    if (firstComma > 0 && secondComma > 0 && thirdComma > 0) {
                        String username = line.substring(firstComma + 1, secondComma);
                        String content = line.substring(thirdComma + 1);
                        String fullMessage = username + ": " + content;
                        chatMessages.push_back(fullMessage);
                    }
                }
            }
            chatFile.close();
        }
    }
}

void loadBlogFromSD() {
    if (!sdCardReady) return;
    
    blogPosts.clear();
    
    if (SD.exists("/root/blog/posts.txt")) {
        File blogFile = SD.open("/root/blog/posts.txt");
        if (blogFile) {
            while (blogFile.available()) {
                String line = blogFile.readStringUntil('\n');
                line.trim();
                
                if (line.length() > 0 && !line.startsWith("#")) {
                    int firstComma = line.indexOf(',');
                    int secondComma = line.indexOf(',', firstComma + 1);
                    int thirdComma = line.indexOf(',', secondComma + 1);
                    
                    if (firstComma > 0 && secondComma > 0 && thirdComma > 0) {
                        String title = line.substring(firstComma + 1, secondComma);
                        String author = line.substring(thirdComma + 1);
                        String fullPost = title + " - " + author;
                        blogPosts.push_back(fullPost);
                    }
                }
            }
            blogFile.close();
        }
    }
}

void logToSD(String message) {
    if (!sdCardReady) return;
    
    File logFile = SD.open("/root/logs/system.log", FILE_APPEND);
    if (logFile) {
        String timestamp = String(millis());
        logFile.println(timestamp + ": " + message);
        logFile.close();
    }
}

void loop() {
    // Обновляем WebSocket
    if (isServerConnected) {
        webSocket.loop();
    }
    
    // Обрабатываем клавиатуру
    handleKeyboard();
    
    // Периодически обновляем данные
    if (millis() - lastScreenUpdate > SCREEN_UPDATE_INTERVAL) {
        lastScreenUpdate = millis();
        
        if (isLoggedIn) {
            if (currentMode == MODE_SERVER) {
                updateServerStats();
                showServerScreen();
            }
        }
        
        // Если не подключены к серверу, продолжаем поиск
        if (!isServerConnected) {
            searchForServer();
        }
    }
    
    delay(50);
}