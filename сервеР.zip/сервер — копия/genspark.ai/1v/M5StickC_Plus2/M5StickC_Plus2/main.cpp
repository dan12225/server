#include <M5StickCPlus2.h>
#include <WiFi.h>
#include <WebSocketsClient.h>
#include <ArduinoJson.h>
#include <HTTPClient.h>
#include <driver/i2s.h>

// Настройки дисплея
#define SCREEN_WIDTH 240
#define SCREEN_HEIGHT 135

// Настройки аудио
#define I2S_WS 0
#define I2S_SD 34
#define I2S_SCK 0
#define SAMPLE_RATE 16000
#define SAMPLE_BITS 16

// Режимы работы
enum Mode {
    MODE_LOGIN,
    MODE_CHAT,
    MODE_BLOG,
    MODE_SERVER_INFO
};

// Глобальные переменные
WebSocketsClient webSocket;
HTTPClient http;

Mode currentMode = MODE_LOGIN;
String currentUser = "";
bool isLoggedIn = false;
bool isRecording = false;
bool isServerConnected = false;

String mainServerIP = "";
std::vector<String> chatMessages;
std::vector<String> blogPosts;

// Переменные интерфейса
int selectedMenuItem = 0;
unsigned long lastButtonPress = 0;
unsigned long lastScreenUpdate = 0;
const unsigned long DEBOUNCE_DELAY = 200;
const unsigned long SCREEN_UPDATE_INTERVAL = 1000;

// Серверная статистика
struct ServerStats {
    int connectedUsers;
    float cpuUsage;
    float memoryUsage;
    int activeServers;
    String serverStatus;
};

ServerStats serverStats;

void setup() {
    M5.begin();
    Serial.begin(115200);
    
    // Настройка дисплея
    M5.Lcd.setRotation(3);
    M5.Lcd.fillScreen(BLACK);
    M5.Lcd.setTextSize(1);
    M5.Lcd.setTextColor(WHITE);
    
    // Инициализация I2S для аудио
    setupAudio();
    
    // Поиск главного сервера
    searchForMainServer();
    
    // Показать экран входа
    showLoginScreen();
    
    Serial.println("M5StickC Plus2 Chat Client started");
}

void setupAudio() {
    i2s_config_t i2s_config = {
        .mode = i2s_mode_t(I2S_MODE_MASTER | I2S_MODE_RX),
        .sample_rate = SAMPLE_RATE,
        .bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT,
        .channel_format = I2S_CHANNEL_FMT_ONLY_LEFT,
        .communication_format = I2S_COMM_FORMAT_I2S,
        .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
        .dma_buf_count = 4,
        .dma_buf_len = 1024,
        .use_apll = false,
        .tx_desc_auto_clear = false,
        .fixed_mclk = 0
    };
    
    i2s_pin_config_t pin_config = {
        .bck_io_num = I2S_SCK,
        .ws_io_num = I2S_WS,
        .data_out_num = I2S_PIN_NO_CHANGE,
        .data_in_num = I2S_SD
    };
    
    i2s_driver_install(I2S_NUM_0, &i2s_config, 0, NULL);
    i2s_set_pin(I2S_NUM_0, &pin_config);
}

void searchForMainServer() {
    M5.Lcd.fillScreen(BLACK);
    M5.Lcd.setCursor(10, 10);
    M5.Lcd.println("Поиск сервера...");
    M5.Lcd.setCursor(10, 30);
    M5.Lcd.println("Сканирование сети:");
    
    // Сканируем WiFi сети
    int networksFound = WiFi.scanNetworks();
    
    for (int i = 0; i < networksFound; i++) {
        String ssid = WiFi.SSID(i);
        if (ssid.startsWith("ESP32-ChatServer") || ssid.startsWith("ESP32-")) {
            M5.Lcd.setCursor(10, 50 + (i * 10));
            M5.Lcd.printf("Найден: %s", ssid.c_str());
            
            // Пытаемся подключиться
            WiFi.begin(ssid.c_str(), "12345678");
            
            int attempts = 0;
            while (WiFi.status() != WL_CONNECTED && attempts < 20) {
                delay(500);
                attempts++;
            }
            
            if (WiFi.status() == WL_CONNECTED) {
                mainServerIP = WiFi.gatewayIP().toString();
                isServerConnected = true;
                
                M5.Lcd.setCursor(10, 70);
                M5.Lcd.printf("Подключено к: %s", mainServerIP.c_str());
                
                // Подключаемся к WebSocket
                connectWebSocket();
                break;
            }
        }
    }
    
    if (!isServerConnected) {
        M5.Lcd.setCursor(10, 90);
        M5.Lcd.println("Сервер не найден!");
        M5.Lcd.println("Режим поиска...");
        
        // Переходим в режим постоянного поиска
        currentMode = MODE_SERVER_INFO;
    }
    
    delay(2000);
}

void connectWebSocket() {
    webSocket.begin(mainServerIP, 81, "/");
    webSocket.onEvent(webSocketEvent);
    webSocket.setReconnectInterval(5000);
}

void webSocketEvent(WStype_t type, uint8_t * payload, size_t length) {
    switch(type) {
        case WStype_DISCONNECTED:
            Serial.println("WebSocket Disconnected");
            isServerConnected = false;
            break;
            
        case WStype_CONNECTED:
            Serial.printf("WebSocket Connected to: %s\n", payload);
            isServerConnected = true;
            break;
            
        case WStype_TEXT: {
            String message = String((char*)payload);
            DynamicJsonDocument doc(1024);
            deserializeJson(doc, message);
            
            String msgType = doc["type"];
            
            if (msgType == "new_message") {
                String username = doc["username"];
                String content = doc["content"];
                String messageType = doc["messageType"];
                
                String fullMessage = username + ": " + content;
                chatMessages.push_back(fullMessage);
                
                // Ограничиваем количество сообщений
                if (chatMessages.size() > 20) {
                    chatMessages.erase(chatMessages.begin());
                }
                
                // Обновляем экран если находимся в чате
                if (currentMode == MODE_CHAT) {
                    showChatScreen();
                }
            }
            break;
        }
        
        case WStype_BIN:
        case WStype_ERROR:
        case WStype_FRAGMENT_TEXT_START:
        case WStype_FRAGMENT_BIN_START:
        case WStype_FRAGMENT:
        case WStype_FRAGMENT_FIN:
            break;
    }
}

void showLoginScreen() {
    M5.Lcd.fillScreen(BLACK);
    M5.Lcd.setCursor(10, 10);
    M5.Lcd.setTextColor(CYAN);
    M5.Lcd.setTextSize(2);
    M5.Lcd.println("M5Stick Chat");
    
    M5.Lcd.setTextSize(1);
    M5.Lcd.setTextColor(WHITE);
    M5.Lcd.setCursor(10, 40);
    M5.Lcd.println("Для входа используйте");
    M5.Lcd.println("веб-интерфейс на:");
    M5.Lcd.println(mainServerIP);
    
    M5.Lcd.setCursor(10, 80);
    M5.Lcd.setTextColor(YELLOW);
    M5.Lcd.println("После входа:");
    M5.Lcd.println("BtnA - Чат");
    M5.Lcd.println("BtnB - Режимы");
    
    M5.Lcd.setCursor(10, 115);
    M5.Lcd.setTextColor(GREEN);
    M5.Lcd.println("M5 - Голос");
}

void showChatScreen() {
    M5.Lcd.fillScreen(BLACK);
    M5.Lcd.setCursor(5, 5);
    M5.Lcd.setTextColor(CYAN);
    M5.Lcd.setTextSize(1);
    M5.Lcd.println("--- ЧАТ ---");
    
    // Показываем последние сообщения
    int startY = 20;
    int maxMessages = min(8, (int)chatMessages.size());
    int startIndex = max(0, (int)chatMessages.size() - maxMessages);
    
    for (int i = startIndex; i < chatMessages.size(); i++) {
        M5.Lcd.setCursor(5, startY + (i - startIndex) * 12);
        M5.Lcd.setTextColor(WHITE);
        
        String msg = chatMessages[i];
        if (msg.length() > 38) {
            msg = msg.substring(0, 35) + "...";
        }
        M5.Lcd.println(msg);
    }
    
    // Статус записи
    if (isRecording) {
        M5.Lcd.setCursor(5, 120);
        M5.Lcd.setTextColor(RED);
        M5.Lcd.println("🎤 ЗАПИСЬ...");
    } else {
        M5.Lcd.setCursor(5, 120);
        M5.Lcd.setTextColor(GREEN);
        M5.Lcd.println("M5 - Записать голос");
    }
}

void showBlogScreen() {
    M5.Lcd.fillScreen(BLACK);
    M5.Lcd.setCursor(5, 5);
    M5.Lcd.setTextColor(MAGENTA);
    M5.Lcd.setTextSize(1);
    M5.Lcd.println("--- БЛОГ ---");
    
    if (blogPosts.empty()) {
        M5.Lcd.setCursor(10, 40);
        M5.Lcd.setTextColor(YELLOW);
        M5.Lcd.println("Постов пока нет");
    } else {
        int startY = 20;
        int maxPosts = min(6, (int)blogPosts.size());
        int startIndex = max(0, (int)blogPosts.size() - maxPosts);
        
        for (int i = startIndex; i < blogPosts.size(); i++) {
            M5.Lcd.setCursor(5, startY + (i - startIndex) * 15);
            M5.Lcd.setTextColor(WHITE);
            
            String post = blogPosts[i];
            if (post.length() > 35) {
                post = post.substring(0, 32) + "...";
            }
            M5.Lcd.println(post);
        }
    }
    
    M5.Lcd.setCursor(5, 120);
    M5.Lcd.setTextColor(GREEN);
    M5.Lcd.println("BtnB - След. режим");
}

void showServerInfoScreen() {
    M5.Lcd.fillScreen(BLACK);
    M5.Lcd.setCursor(5, 5);
    M5.Lcd.setTextColor(GREEN);
    M5.Lcd.setTextSize(1);
    M5.Lcd.println("--- СЕРВЕР ---");
    
    if (isServerConnected) {
        M5.Lcd.setCursor(5, 20);
        M5.Lcd.setTextColor(WHITE);
        M5.Lcd.printf("IP: %s\n", mainServerIP.c_str());
        
        M5.Lcd.setCursor(5, 35);
        M5.Lcd.printf("Польз: %d\n", serverStats.connectedUsers);
        
        M5.Lcd.setCursor(5, 50);
        M5.Lcd.printf("CPU: %.1f%%\n", serverStats.cpuUsage);
        
        M5.Lcd.setCursor(5, 65);
        M5.Lcd.printf("RAM: %.1f%%\n", serverStats.memoryUsage);
        
        M5.Lcd.setCursor(5, 80);
        M5.Lcd.printf("Серверов: %d\n", serverStats.activeServers);
        
        M5.Lcd.setCursor(5, 100);
        M5.Lcd.setTextColor(CYAN);
        M5.Lcd.println("Статус: Активен");
    } else {
        M5.Lcd.setCursor(5, 40);
        M5.Lcd.setTextColor(RED);
        M5.Lcd.println("Поиск серверов...");
        
        M5.Lcd.setCursor(5, 60);
        M5.Lcd.setTextColor(YELLOW);
        M5.Lcd.println("Автономный режим");
        
        // В автономном режиме ищем другие серверы
        searchForOtherServers();
    }
    
    M5.Lcd.setCursor(5, 120);
    M5.Lcd.setTextColor(GREEN);
    M5.Lcd.println("BtnB - След. режим");
}

void searchForOtherServers() {
    // Логика поиска других серверов M5StickC Plus2
    // Сканируем WiFi сети и ищем другие ESP32 устройства
    static unsigned long lastScan = 0;
    if (millis() - lastScan > 10000) { // Сканируем каждые 10 секунд
        lastScan = millis();
        
        int networksFound = WiFi.scanNetworks();
        for (int i = 0; i < networksFound; i++) {
            String ssid = WiFi.SSID(i);
            if (ssid.startsWith("ESP32-") && ssid != WiFi.SSID()) {
                // Найден другой сервер, пытаемся подключиться
                attemptConnectionToServer(ssid);
                break;
            }
        }
    }
}

void attemptConnectionToServer(String ssid) {
    WiFi.begin(ssid.c_str(), "12345678");
    
    int attempts = 0;
    while (WiFi.status() != WL_CONNECTED && attempts < 10) {
        delay(500);
        attempts++;
    }
    
    if (WiFi.status() == WL_CONNECTED) {
        mainServerIP = WiFi.gatewayIP().toString();
        isServerConnected = true;
        connectWebSocket();
        
        M5.Lcd.setCursor(5, 80);
        M5.Lcd.setTextColor(GREEN);
        M5.Lcd.println("Подключен!");
    }
}

void startVoiceRecording() {
    if (!isRecording && isServerConnected) {
        isRecording = true;
        
        // Начинаем запись аудио
        size_t bytesRead = 0;
        uint8_t audioBuffer[1024];
        
        // Записываем 3 секунды аудио
        unsigned long recordStart = millis();
        std::vector<uint8_t> audioData;
        
        while (millis() - recordStart < 3000) {
            i2s_read(I2S_NUM_0, audioBuffer, sizeof(audioBuffer), &bytesRead, portMAX_DELAY);
            
            for (size_t i = 0; i < bytesRead; i++) {
                audioData.push_back(audioBuffer[i]);
            }
            
            // Обновляем экран чтобы показать прогресс
            if (currentMode == MODE_CHAT) {
                showChatScreen();
            }
            
            delay(10);
        }
        
        isRecording = false;
        
        // Отправляем аудио на сервер
        sendVoiceMessage(audioData);
    }
}

void sendVoiceMessage(std::vector<uint8_t>& audioData) {
    if (!isServerConnected || audioData.empty()) return;
    
    // Формируем HTTP запрос для отправки аудио
    HTTPClient http;
    http.begin("http://" + mainServerIP + "/api/uploadVoice");
    http.addHeader("Content-Type", "audio/wav");
    
    // Конвертируем в нужный формат и отправляем
    // Для упрощения пока просто отправляем текстовое сообщение
    http.end();
    
    // Отправляем текстовое уведомление о голосовом сообщении
    sendTextMessage("[Голосовое сообщение]");
}

void sendTextMessage(String message) {
    if (!isServerConnected) return;
    
    DynamicJsonDocument doc(512);
    doc["type"] = "chat_message";
    doc["username"] = currentUser;
    doc["message"] = message;
    doc["messageType"] = "text";
    
    String jsonString;
    serializeJson(doc, jsonString);
    
    webSocket.sendTXT(jsonString);
}

void loadChatHistory() {
    if (!isServerConnected) return;
    
    HTTPClient http;
    http.begin("http://" + mainServerIP + "/api/getChatHistory");
    
    int httpResponseCode = http.GET();
    
    if (httpResponseCode == 200) {
        String response = http.getString();
        
        DynamicJsonDocument doc(4096);
        deserializeJson(doc, response);
        
        JsonArray messages = doc["messages"];
        chatMessages.clear();
        
        for (JsonObject message : messages) {
            String username = message["username"];
            String content = message["content"];
            String fullMessage = username + ": " + content;
            chatMessages.push_back(fullMessage);
        }
    }
    
    http.end();
}

void loadBlogPosts() {
    if (!isServerConnected) return;
    
    HTTPClient http;
    http.begin("http://" + mainServerIP + "/api/getBlogPosts");
    
    int httpResponseCode = http.GET();
    
    if (httpResponseCode == 200) {
        String response = http.getString();
        
        DynamicJsonDocument doc(4096);
        deserializeJson(doc, response);
        
        JsonArray posts = doc["posts"];
        blogPosts.clear();
        
        for (JsonObject post : posts) {
            String title = post["title"];
            String author = post["author"];
            String fullPost = title + " - " + author;
            blogPosts.push_back(fullPost);
        }
    }
    
    http.end();
}

void updateServerStats() {
    if (!isServerConnected) return;
    
    HTTPClient http;
    http.begin("http://" + mainServerIP + "/api/getServerStatus");
    
    int httpResponseCode = http.GET();
    
    if (httpResponseCode == 200) {
        String response = http.getString();
        
        DynamicJsonDocument doc(1024);
        deserializeJson(doc, response);
        
        serverStats.connectedUsers = doc["connectedUsers"];
        serverStats.cpuUsage = doc["cpuUsage"];
        serverStats.memoryUsage = doc["memoryUsage"];
        serverStats.activeServers = doc["activeServers"];
    }
    
    http.end();
}

void handleButtons() {
    M5.update();
    
    if (millis() - lastButtonPress < DEBOUNCE_DELAY) {
        return;
    }
    
    // Кнопка A (левая боковая) - переключение режимов или действие
    if (M5.BtnA.wasPressed()) {
        lastButtonPress = millis();
        
        if (!isLoggedIn) {
            // Если не вошли, показываем инструкцию по входу
            showLoginScreen();
        } else {
            // Переключаемся на чат или выполняем действие в чате
            if (currentMode != MODE_CHAT) {
                currentMode = MODE_CHAT;
                loadChatHistory();
                showChatScreen();
            }
        }
    }
    
    // Кнопка B (правая боковая) - переключение режимов
    if (M5.BtnB.wasPressed()) {
        lastButtonPress = millis();
        
        if (isLoggedIn) {
            // Циклически переключаем режимы
            switch (currentMode) {
                case MODE_CHAT:
                    currentMode = MODE_BLOG;
                    loadBlogPosts();
                    showBlogScreen();
                    break;
                case MODE_BLOG:
                    currentMode = MODE_SERVER_INFO;
                    updateServerStats();
                    showServerInfoScreen();
                    break;
                case MODE_SERVER_INFO:
                    currentMode = MODE_CHAT;
                    loadChatHistory();
                    showChatScreen();
                    break;
                default:
                    currentMode = MODE_CHAT;
                    break;
            }
        }
    }
    
    // Кнопка M5 (на корпусе) - голосовое сообщение
    if (M5.BtnPWR.wasPressed()) {
        lastButtonPress = millis();
        
        if (isLoggedIn && currentMode == MODE_CHAT) {
            startVoiceRecording();
        }
    }
}

void loop() {
    // Обновляем WebSocket
    if (isServerConnected) {
        webSocket.loop();
    }
    
    // Обрабатываем кнопки
    handleButtons();
    
    // Периодически обновляем экран и данные
    if (millis() - lastScreenUpdate > SCREEN_UPDATE_INTERVAL) {
        lastScreenUpdate = millis();
        
        if (isLoggedIn) {
            switch (currentMode) {
                case MODE_CHAT:
                    // Чат обновляется через WebSocket
                    break;
                case MODE_BLOG:
                    loadBlogPosts();
                    showBlogScreen();
                    break;
                case MODE_SERVER_INFO:
                    updateServerStats();
                    showServerInfoScreen();
                    break;
            }
        }
        
        // Если не подключены к серверу, продолжаем поиск
        if (!isServerConnected) {
            searchForMainServer();
        }
    }
    
    delay(50);
}