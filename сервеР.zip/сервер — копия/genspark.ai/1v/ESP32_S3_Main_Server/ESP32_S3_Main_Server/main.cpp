#include <Arduino.h>
#include <WiFi.h>
#include <ESPAsyncWebServer.h>
#include <WebSocketsServer.h>
#include <FS.h>
#include <SD.h>
#include <ArduinoJson.h>
#include <SPIFFS.h>
#include <ESPmDNS.h>

// Пины для SD карты и кнопки
#define BUTTON_PIN 2
#define SD_CS 15
#define SD_MOSI 23
#define SD_MISO 19
#define SD_SCK 18

// Сетевые настройки
#define AP_SSID "ESP32-ChatServer"
#define AP_PASSWORD "12345678"
#define WEB_PORT 80
#define WEBSOCKET_PORT 81

// Глобальные объекты
AsyncWebServer server(WEB_PORT);
WebSocketsServer webSocket = WebSocketsServer(WEBSOCKET_PORT);

// Переменные состояния
bool serverActive = false;
bool sdCardReady = false;
String serverId = "main";
unsigned long lastHeartbeat = 0;

// Структуры данных
struct User {
    String username;
    String password;
    bool isAdmin;
    bool isBanned;
    String banUntil;
    String avatarPath;
    unsigned long lastActivity;
};

struct ChatMessage {
    String username;
    String content;
    String messageType;
    String timestamp;
    String filePath;
};

struct ConnectedServer {
    String id;
    String ip;
    unsigned long lastPing;
    bool isActive;
};

std::vector<User> users;
std::vector<ChatMessage> chatHistory;
std::vector<ConnectedServer> connectedServers;
std::map<String, String> activeSessions;

// Функции защиты
std::map<String, std::vector<unsigned long>> rateLimitMap;
const int MAX_REQUESTS_PER_MINUTE = 30;

bool checkRateLimit(String clientIP) {
    unsigned long currentTime = millis();
    
    if (rateLimitMap.find(clientIP) == rateLimitMap.end()) {
        rateLimitMap[clientIP] = std::vector<unsigned long>();
    }
    
    std::vector<unsigned long>& requests = rateLimitMap[clientIP];
    
    // Удаляем старые записи (старше 60 секунд)
    requests.erase(
        std::remove_if(requests.begin(), requests.end(),
            [currentTime](unsigned long time) {
                return currentTime - time > 60000;
            }),
        requests.end()
    );
    
    if (requests.size() >= MAX_REQUESTS_PER_MINUTE) {
        return false; // Превышен лимит
    }
    
    requests.push_back(currentTime);
    return true;
}

String sanitizeInput(String input) {
    // Защита от XSS
    input.replace("<", "&lt;");
    input.replace(">", "&gt;");
    input.replace("\"", "&quot;");
    input.replace("'", "&#x27;");
    input.replace("/", "&#x2F;");
    input.replace("&", "&amp;");
    
    // Обрезаем длину
    if (input.length() > MAX_MESSAGE_LENGTH) {
        input = input.substring(0, MAX_MESSAGE_LENGTH);
    }
    
    return input;
}

String generateSessionId() {
    String sessionId = "";
    for (int i = 0; i < 32; i++) {
        sessionId += String(random(0, 16), HEX);
    }
    return sessionId;
}

// Инициализация SD карты
bool initSDCard() {
    if (!SD.begin(SD_CS)) {
        Serial.println("SD Card initialization failed!");
        return false;
    }
    
    // Проверяем размер SD карты
    uint64_t cardSize = SD.cardSize() / (1024 * 1024);
    Serial.printf("SD Card Size: %lluMB\n", cardSize);
    
    if (cardSize < 2048) { // Меньше 2ГБ
        Serial.println("SD Card too small! Need at least 2GB");
        return false;
    }
    
    // Создаем структуру папок
    createDirectories();
    
    // Проверяем наличие файла администратора
    if (!SD.exists("/root/users/admin/pas.txt")) {
        createAdminAccount();
    }
    
    loadUsers();
    loadChatHistory();
    
    return true;
}

void createDirectories() {
    SD.mkdir("/root");
    SD.mkdir("/root/users");
    SD.mkdir("/root/users/admin");
    SD.mkdir("/root/avatars");
    SD.mkdir("/root/chat");
    SD.mkdir("/root/chat/files");
    SD.mkdir("/root/chat/audio");
    SD.mkdir("/root/chat/images");
    SD.mkdir("/root/logs");
    SD.mkdir("/root/config");
    SD.mkdir("/root/blog");
    SD.mkdir("/root/support");
    SD.mkdir("/root/files");
    SD.mkdir("/root/temp");
}

void createAdminAccount() {
    File adminFile = SD.open("/root/users/admin/pas.txt", FILE_WRITE);
    if (adminFile) {
        adminFile.println("admin:7428");
        adminFile.close();
    }
    
    File banFile = SD.open("/root/users/admin/ban.txt", FILE_WRITE);
    if (banFile) {
        banFile.println("# История банов администратора");
        banFile.close();
    }
}

void loadUsers() {
    users.clear();
    
    File root = SD.open("/root/users");
    File file = root.openNextFile();
    
    while (file) {
        if (file.isDirectory()) {
            String username = file.name();
            String pasFilePath = "/root/users/" + username + "/pas.txt";
            
            if (SD.exists(pasFilePath)) {
                File pasFile = SD.open(pasFilePath);
                if (pasFile) {
                    String line = pasFile.readStringUntil('\n');
                    line.trim();
                    
                    int colonIndex = line.indexOf(':');
                    if (colonIndex > 0) {
                        User user;
                        user.username = line.substring(0, colonIndex);
                        user.password = line.substring(colonIndex + 1);
                        user.isAdmin = (user.username == "admin");
                        user.isBanned = false;
                        user.avatarPath = "/root/users/" + username + "/avatar.jpg";
                        user.lastActivity = millis();
                        
                        users.push_back(user);
                    }
                    pasFile.close();
                }
            }
        }
        file = root.openNextFile();
    }
    root.close();
}

void loadChatHistory() {
    chatHistory.clear();
    
    if (SD.exists("/root/chat/messages.txt")) {
        File file = SD.open("/root/chat/messages.txt");
        if (file) {
            while (file.available()) {
                String line = file.readStringUntil('\n');
                line.trim();
                
                if (line.length() > 0 && !line.startsWith("#")) {
                    // Формат: timestamp,username,message_type,content
                    int firstComma = line.indexOf(',');
                    int secondComma = line.indexOf(',', firstComma + 1);
                    int thirdComma = line.indexOf(',', secondComma + 1);
                    
                    if (firstComma > 0 && secondComma > 0 && thirdComma > 0) {
                        ChatMessage msg;
                        msg.timestamp = line.substring(0, firstComma);
                        msg.username = line.substring(firstComma + 1, secondComma);
                        msg.messageType = line.substring(secondComma + 1, thirdComma);
                        msg.content = line.substring(thirdComma + 1);
                        
                        chatHistory.push_back(msg);
                    }
                }
            }
            file.close();
        }
    }
}

// Аутентификация пользователя
bool authenticateUser(String username, String password) {
    for (const auto& user : users) {
        if (user.username == username && user.password == password && !user.isBanned) {
            return true;
        }
    }
    return false;
}

// Регистрация нового пользователя
bool registerUser(String username, String password) {
    // Проверяем, что пользователь не существует
    for (const auto& user : users) {
        if (user.username == username) {
            return false;
        }
    }
    
    // Создаем папку пользователя
    String userDir = "/root/users/" + username;
    SD.mkdir(userDir);
    
    // Создаем файл пароля
    File pasFile = SD.open(userDir + "/pas.txt", FILE_WRITE);
    if (pasFile) {
        pasFile.println(username + ":" + password);
        pasFile.close();
    }
    
    // Создаем файл истории банов
    File banFile = SD.open(userDir + "/ban.txt", FILE_WRITE);
    if (banFile) {
        banFile.println("# История банов пользователя " + username);
        banFile.close();
    }
    
    // Добавляем в память
    User newUser;
    newUser.username = username;
    newUser.password = password;
    newUser.isAdmin = false;
    newUser.isBanned = false;
    newUser.avatarPath = userDir + "/avatar.jpg";
    newUser.lastActivity = millis();
    
    users.push_back(newUser);
    
    return true;
}

// Сохранение сообщения в чат
void saveMessage(String username, String content, String messageType = "text") {
    File file = SD.open("/root/chat/messages.txt", FILE_APPEND);
    if (file) {
        String timestamp = String(millis());
        String line = timestamp + "," + username + "," + messageType + "," + content;
        file.println(line);
        file.close();
        
        // Добавляем в память
        ChatMessage msg;
        msg.timestamp = timestamp;
        msg.username = username;
        msg.messageType = messageType;
        msg.content = content;
        
        chatHistory.push_back(msg);
        
        // Ограничиваем историю чата
        if (chatHistory.size() > 1000) {
            chatHistory.erase(chatHistory.begin());
        }
        
        // Отправляем всем подключенным клиентам
        DynamicJsonDocument doc(1024);
        doc["type"] = "new_message";
        doc["username"] = username;
        doc["content"] = content;
        doc["messageType"] = messageType;
        doc["timestamp"] = timestamp;
        
        String messageStr;
        serializeJson(doc, messageStr);
        webSocket.broadcastTXT(messageStr);
    }
}

// HTML главной страницы
String getIndexHTML() {
    return R"(
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ESP32 Chat Server</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            margin: 0; 
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: rgba(255,255,255,0.1);
            padding: 20px;
            border-radius: 15px;
            backdrop-filter: blur(10px);
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        .login-form {
            background: rgba(255,255,255,0.2);
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
        }
        .login-form input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: none;
            border-radius: 5px;
            background: rgba(255,255,255,0.9);
            color: #333;
        }
        .login-form button {
            width: 100%;
            padding: 12px;
            background: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .login-form button:hover {
            background: #45a049;
        }
        .nav-buttons {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin: 20px 0;
        }
        .nav-btn {
            padding: 10px 20px;
            background: rgba(255,255,255,0.3);
            border: none;
            border-radius: 5px;
            color: white;
            cursor: pointer;
            text-decoration: none;
        }
        .nav-btn:hover {
            background: rgba(255,255,255,0.5);
        }
        #loginSection {
            display: block;
        }
        #chatSection, #blogSection, #supportSection, #accountSection, #adminSection {
            display: none;
        }
        .chat-container {
            height: 400px;
            overflow-y: auto;
            background: rgba(0,0,0,0.3);
            padding: 10px;
            border-radius: 5px;
            margin: 10px 0;
        }
        .message {
            margin: 5px 0;
            padding: 8px;
            background: rgba(255,255,255,0.1);
            border-radius: 5px;
        }
        .message-username {
            font-weight: bold;
            color: #FFD700;
        }
        .input-group {
            display: flex;
            gap: 10px;
            margin: 10px 0;
        }
        .input-group input {
            flex: 1;
            padding: 10px;
            border: none;
            border-radius: 5px;
        }
        .input-group button {
            padding: 10px 20px;
            background: #2196F3;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .blog-post {
            background: rgba(255,255,255,0.1);
            padding: 15px;
            margin: 10px 0;
            border-radius: 8px;
        }
        .blog-post h3 {
            margin-top: 0;
            color: #FFD700;
        }
        .server-status {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        .status-card {
            background: rgba(255,255,255,0.1);
            padding: 15px;
            border-radius: 8px;
            text-align: center;
        }
        .status-value {
            font-size: 24px;
            font-weight: bold;
            color: #4CAF50;
        }
        .file-upload {
            margin: 10px 0;
        }
        .file-upload input[type="file"] {
            background: rgba(255,255,255,0.9);
            padding: 5px;
            border-radius: 5px;
            width: 100%;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🚀 ESP32 Chat Server</h1>
            <p>Добро пожаловать в распределенную сеть чата!</p>
        </div>
        
        <!-- Секция входа -->
        <div id="loginSection">
            <div class="login-form">
                <h2>Вход в систему</h2>
                <input type="text" id="username" placeholder="Логин" required>
                <input type="password" id="password" placeholder="Пароль" required>
                <button onclick="login()">Войти</button>
            </div>
        </div>
        
        <!-- Навигация -->
        <div class="nav-buttons" style="display: none;" id="navigation">
            <button class="nav-btn" onclick="showSection('chat')">Чат</button>
            <button class="nav-btn" onclick="showSection('blog')">Блог</button>
            <button class="nav-btn" onclick="showSection('support')">Поддержка</button>
            <button class="nav-btn" onclick="showSection('account')">Аккаунт</button>
            <button class="nav-btn" onclick="showSection('admin')" id="adminBtn" style="display: none;">Админ</button>
            <button class="nav-btn" onclick="logout()">Выход</button>
        </div>
        
        <!-- Секция чата -->
        <div id="chatSection">
            <h2>💬 Чат</h2>
            <div class="chat-container" id="chatMessages"></div>
            <div class="input-group">
                <input type="text" id="messageInput" placeholder="Сообщение (макс 100 символов)" maxlength="100">
                <button onclick="sendMessage()">Отправить</button>
            </div>
            <div class="file-upload">
                <input type="file" id="fileInput" accept="image/*,video/*,audio/*,.pdf,.doc,.docx,.txt">
                <button onclick="uploadFile()">Загрузить файл</button>
            </div>
        </div>
        
        <!-- Секция блога -->
        <div id="blogSection">
            <h2>📝 Блог</h2>
            <div id="blogPosts"></div>
        </div>
        
        <!-- Секция поддержки -->
        <div id="supportSection">
            <h2>🛠️ Техническая поддержка</h2>
            <div class="input-group">
                <input type="text" id="supportMessage" placeholder="Ваш вопрос администратору">
                <button onclick="sendSupportMessage()">Отправить</button>
            </div>
            <div id="supportTickets"></div>
        </div>
        
        <!-- Секция аккаунта -->
        <div id="accountSection">
            <h2>👤 Аккаунт</h2>
            <div class="file-upload">
                <label>Изменить аватар:</label>
                <input type="file" id="avatarInput" accept="image/*">
                <button onclick="uploadAvatar()">Обновить аватар</button>
            </div>
        </div>
        
        <!-- Админ панель -->
        <div id="adminSection">
            <h2>⚡ Панель администратора</h2>
            
            <div class="server-status">
                <div class="status-card">
                    <div>Подключенные пользователи</div>
                    <div class="status-value" id="connectedUsers">0</div>
                </div>
                <div class="status-card">
                    <div>Использование CPU</div>
                    <div class="status-value" id="cpuUsage">0%</div>
                </div>
                <div class="status-card">
                    <div>Использование памяти</div>
                    <div class="status-value" id="memoryUsage">0%</div>
                </div>
                <div class="status-card">
                    <div>Активные серверы</div>
                    <div class="status-value" id="activeServers">1</div>
                </div>
            </div>
            
            <h3>Управление пользователями</h3>
            <div class="input-group">
                <input type="text" id="banUsername" placeholder="Логин пользователя">
                <input type="text" id="banDuration" placeholder="Время бана (мин)">
                <button onclick="banUser()">Забанить</button>
            </div>
            
            <h3>Создать пост в блоге</h3>
            <div class="input-group">
                <input type="text" id="blogTitle" placeholder="Заголовок поста">
            </div>
            <div class="input-group">
                <textarea id="blogContent" placeholder="Содержание поста" rows="4" style="width: 100%; padding: 10px; border: none; border-radius: 5px;"></textarea>
            </div>
            <button onclick="createBlogPost()">Создать пост</button>
        </div>
    </div>

    <script>
        let socket;
        let currentUser = '';
        let isAdmin = false;
        
        // Подключение к WebSocket
        function connectWebSocket() {
            socket = new WebSocket('ws://' + window.location.hostname + ':81');
            
            socket.onopen = function(event) {
                console.log('WebSocket подключен');
            };
            
            socket.onmessage = function(event) {
                const data = JSON.parse(event.data);
                handleWebSocketMessage(data);
            };
            
            socket.onclose = function(event) {
                console.log('WebSocket отключен');
                setTimeout(connectWebSocket, 3000); // Переподключение через 3 секунды
            };
        }
        
        function handleWebSocketMessage(data) {
            if (data.type === 'new_message') {
                displayMessage(data);
            } else if (data.type === 'server_status') {
                updateServerStatus(data);
            }
        }
        
        function login() {
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            
            fetch('/api/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({username: username, password: password})
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    currentUser = username;
                    isAdmin = data.isAdmin;
                    
                    document.getElementById('loginSection').style.display = 'none';
                    document.getElementById('navigation').style.display = 'flex';
                    
                    if (isAdmin) {
                        document.getElementById('adminBtn').style.display = 'block';
                    }
                    
                    connectWebSocket();
                    showSection('chat');
                    loadChatHistory();
                } else {
                    alert('Неверный логин или пароль');
                }
            })
            .catch(error => {
                console.error('Ошибка:', error);
                alert('Ошибка соединения');
            });
        }
        
        function logout() {
            currentUser = '';
            isAdmin = false;
            
            document.getElementById('loginSection').style.display = 'block';
            document.getElementById('navigation').style.display = 'none';
            
            hideAllSections();
            
            if (socket) {
                socket.close();
            }
        }
        
        function showSection(sectionName) {
            hideAllSections();
            document.getElementById(sectionName + 'Section').style.display = 'block';
            
            if (sectionName === 'chat') {
                loadChatHistory();
            } else if (sectionName === 'blog') {
                loadBlogPosts();
            } else if (sectionName === 'support') {
                loadSupportTickets();
            } else if (sectionName === 'admin' && isAdmin) {
                updateAdminPanel();
            }
        }
        
        function hideAllSections() {
            document.getElementById('chatSection').style.display = 'none';
            document.getElementById('blogSection').style.display = 'none';
            document.getElementById('supportSection').style.display = 'none';
            document.getElementById('accountSection').style.display = 'none';
            document.getElementById('adminSection').style.display = 'none';
        }
        
        function sendMessage() {
            const messageInput = document.getElementById('messageInput');
            const message = messageInput.value.trim();
            
            if (message && message.length <= 100) {
                fetch('/api/sendMessage', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        username: currentUser,
                        message: message,
                        type: 'text'
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        messageInput.value = '';
                    }
                });
            }
        }
        
        function displayMessage(messageData) {
            const chatMessages = document.getElementById('chatMessages');
            const messageDiv = document.createElement('div');
            messageDiv.className = 'message';
            messageDiv.innerHTML = `
                <span class="message-username">${messageData.username}:</span>
                ${messageData.content}
            `;
            chatMessages.appendChild(messageDiv);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }
        
        function loadChatHistory() {
            fetch('/api/getChatHistory')
            .then(response => response.json())
            .then(data => {
                const chatMessages = document.getElementById('chatMessages');
                chatMessages.innerHTML = '';
                
                data.messages.forEach(message => {
                    displayMessage(message);
                });
            });
        }
        
        function loadBlogPosts() {
            fetch('/api/getBlogPosts')
            .then(response => response.json())
            .then(data => {
                const blogPosts = document.getElementById('blogPosts');
                blogPosts.innerHTML = '';
                
                data.posts.forEach(post => {
                    const postDiv = document.createElement('div');
                    postDiv.className = 'blog-post';
                    postDiv.innerHTML = `
                        <h3>${post.title}</h3>
                        <p>${post.content}</p>
                        <small>Автор: ${post.author}</small>
                    `;
                    blogPosts.appendChild(postDiv);
                });
            });
        }
        
        function sendSupportMessage() {
            const supportInput = document.getElementById('supportMessage');
            const message = supportInput.value.trim();
            
            if (message) {
                fetch('/api/sendSupportMessage', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        username: currentUser,
                        message: message
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        supportInput.value = '';
                        alert('Сообщение отправлено администратору');
                    }
                });
            }
        }
        
        function banUser() {
            if (!isAdmin) return;
            
            const username = document.getElementById('banUsername').value;
            const duration = document.getElementById('banDuration').value;
            
            if (username && duration) {
                fetch('/api/banUser', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        username: username,
                        duration: duration,
                        reason: 'Нарушение правил'
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Пользователь забанен');
                        document.getElementById('banUsername').value = '';
                        document.getElementById('banDuration').value = '';
                    }
                });
            }
        }
        
        function createBlogPost() {
            if (!isAdmin) return;
            
            const title = document.getElementById('blogTitle').value;
            const content = document.getElementById('blogContent').value;
            
            if (title && content) {
                fetch('/api/createBlogPost', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        title: title,
                        content: content,
                        author: currentUser
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Пост создан');
                        document.getElementById('blogTitle').value = '';
                        document.getElementById('blogContent').value = '';
                    }
                });
            }
        }
        
        function updateAdminPanel() {
            fetch('/api/getServerStatus')
            .then(response => response.json())
            .then(data => {
                document.getElementById('connectedUsers').textContent = data.connectedUsers;
                document.getElementById('cpuUsage').textContent = data.cpuUsage + '%';
                document.getElementById('memoryUsage').textContent = data.memoryUsage + '%';
                document.getElementById('activeServers').textContent = data.activeServers;
            });
        }
        
        // Автоматическое обновление админ-панели каждые 5 секунд
        setInterval(() => {
            if (isAdmin && document.getElementById('adminSection').style.display === 'block') {
                updateAdminPanel();
            }
        }, 5000);
        
        // Обработка Enter в поле ввода сообщения
        document.getElementById('messageInput').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                sendMessage();
            }
        });
        
        // Обработка Enter в полях логина
        document.getElementById('username').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                document.getElementById('password').focus();
            }
        });
        
        document.getElementById('password').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                login();
            }
        });
    </script>
</body>
</html>
    )";
}

// WebSocket обработчик событий
void webSocketEvent(uint8_t num, WStype_t type, uint8_t * payload, size_t length) {
    switch(type) {
        case WStype_DISCONNECTED:
            Serial.printf("[%u] Disconnected!\n", num);
            break;
            
        case WStype_CONNECTED: {
            IPAddress ip = webSocket.remoteIP(num);
            Serial.printf("[%u] Connected from %d.%d.%d.%d url: %s\n", num, ip[0], ip[1], ip[2], ip[3], payload);
            break;
        }
        
        case WStype_TEXT:
            Serial.printf("[%u] get Text: %s\n", num, payload);
            
            // Парсим JSON сообщение
            DynamicJsonDocument doc(1024);
            deserializeJson(doc, payload);
            
            String type = doc["type"];
            
            if (type == "ping") {
                // Отвечаем на пинг
                webSocket.sendTXT(num, "{\"type\":\"pong\"}");
            }
            break;
            
        case WStype_BIN:
            Serial.printf("[%u] get binary length: %u\n", num, length);
            break;
            
        default:
            break;
    }
}

void setup() {
    Serial.begin(115200);
    Serial.println("ESP32 Chat Server starting...");
    
    // Инициализация пина кнопки
    pinMode(BUTTON_PIN, INPUT_PULLUP);
    
    // Инициализация SD карты
    if (!initSDCard()) {
        Serial.println("Failed to initialize SD card. Server cannot start.");
        while(1) {
            delay(1000);
        }
    }
    
    sdCardReady = true;
    Serial.println("SD Card initialized successfully");
    
    // Запуск WiFi в режиме Access Point
    WiFi.mode(WIFI_AP);
    WiFi.softAP(AP_SSID, AP_PASSWORD);
    
    IPAddress IP = WiFi.softAPIP();
    Serial.print("AP IP address: ");
    Serial.println(IP);
    
    // Настройка mDNS
    if (MDNS.begin("esp32-chat")) {
        Serial.println("MDNS responder started");
        MDNS.addService("http", "tcp", 80);
    }
    
    // Настройка веб-сервера
    setupWebServer();
    
    // Запуск WebSocket сервера
    webSocket.begin();
    webSocket.onEvent(webSocketEvent);
    
    serverActive = true;
    Serial.println("Server started successfully!");
    Serial.printf("Connect to WiFi network: %s\n", AP_SSID);
    Serial.printf("Password: %s\n", AP_PASSWORD);
    Serial.printf("Open browser and go to: http://%s\n", IP.toString().c_str());
}

void setupWebServer() {
    // Главная страница
    server.on("/", HTTP_GET, [](AsyncWebServerRequest *request){
        if (!checkRateLimit(request->client()->remoteIP().toString())) {
            request->send(429, "text/plain", "Too Many Requests");
            return;
        }
        request->send(200, "text/html", getIndexHTML());
    });
    
    // API: Вход в систему
    server.on("/api/login", HTTP_POST, [](AsyncWebServerRequest *request){}, NULL,
        [](AsyncWebServerRequest *request, uint8_t *data, size_t len, size_t index, size_t total){
            if (!checkRateLimit(request->client()->remoteIP().toString())) {
                request->send(429, "application/json", "{\"success\":false,\"error\":\"Too many requests\"}");
                return;
            }
            
            DynamicJsonDocument doc(1024);
            deserializeJson(doc, (char*)data);
            
            String username = doc["username"];
            String password = doc["password"];
            
            username = sanitizeInput(username);
            password = sanitizeInput(password);
            
            if (authenticateUser(username, password)) {
                String sessionId = generateSessionId();
                activeSessions[sessionId] = username;
                
                bool isUserAdmin = false;
                for (const auto& user : users) {
                    if (user.username == username) {
                        isUserAdmin = user.isAdmin;
                        break;
                    }
                }
                
                DynamicJsonDocument response(512);
                response["success"] = true;
                response["sessionId"] = sessionId;
                response["isAdmin"] = isUserAdmin;
                
                String responseStr;
                serializeJson(response, responseStr);
                
                AsyncWebServerResponse *resp = request->beginResponse(200, "application/json", responseStr);
                resp->addHeader("Set-Cookie", "sessionId=" + sessionId + "; Path=/");
                request->send(resp);
                
                Serial.printf("User logged in: %s\n", username.c_str());
            } else {
                request->send(200, "application/json", "{\"success\":false,\"error\":\"Invalid credentials\"}");
            }
        });
    
    // API: Отправка сообщения
    server.on("/api/sendMessage", HTTP_POST, [](AsyncWebServerRequest *request){}, NULL,
        [](AsyncWebServerRequest *request, uint8_t *data, size_t len, size_t index, size_t total){
            if (!checkRateLimit(request->client()->remoteIP().toString())) {
                request->send(429, "application/json", "{\"success\":false}");
                return;
            }
            
            DynamicJsonDocument doc(1024);
            deserializeJson(doc, (char*)data);
            
            String username = doc["username"];
            String message = doc["message"];
            String messageType = doc["type"];
            
            username = sanitizeInput(username);
            message = sanitizeInput(message);
            messageType = sanitizeInput(messageType);
            
            saveMessage(username, message, messageType);
            request->send(200, "application/json", "{\"success\":true}");
        });
    
    // API: Получение истории чата
    server.on("/api/getChatHistory", HTTP_GET, [](AsyncWebServerRequest *request){
        DynamicJsonDocument doc(4096);
        JsonArray messages = doc.createNestedArray("messages");
        
        // Отправляем последние 50 сообщений
        int start = max(0, (int)chatHistory.size() - 50);
        for (int i = start; i < chatHistory.size(); i++) {
            JsonObject msg = messages.createNestedObject();
            msg["username"] = chatHistory[i].username;
            msg["content"] = chatHistory[i].content;
            msg["messageType"] = chatHistory[i].messageType;
            msg["timestamp"] = chatHistory[i].timestamp;
        }
        
        String responseStr;
        serializeJson(doc, responseStr);
        request->send(200, "application/json", responseStr);
    });
    
    // API: Создание поста в блоге (только админ)
    server.on("/api/createBlogPost", HTTP_POST, [](AsyncWebServerRequest *request){}, NULL,
        [](AsyncWebServerRequest *request, uint8_t *data, size_t len, size_t index, size_t total){
            DynamicJsonDocument doc(1024);
            deserializeJson(doc, (char*)data);
            
            String title = sanitizeInput(doc["title"]);
            String content = sanitizeInput(doc["content"]);
            String author = sanitizeInput(doc["author"]);
            
            // Проверяем, что пользователь админ
            bool isAuthorAdmin = false;
            for (const auto& user : users) {
                if (user.username == author && user.isAdmin) {
                    isAuthorAdmin = true;
                    break;
                }
            }
            
            if (isAuthorAdmin) {
                File blogFile = SD.open("/root/blog/posts.txt", FILE_APPEND);
                if (blogFile) {
                    String timestamp = String(millis());
                    String line = timestamp + "," + title + "," + content + "," + author;
                    blogFile.println(line);
                    blogFile.close();
                    
                    request->send(200, "application/json", "{\"success\":true}");
                } else {
                    request->send(500, "application/json", "{\"success\":false}");
                }
            } else {
                request->send(403, "application/json", "{\"success\":false,\"error\":\"Access denied\"}");
            }
        });
    
    // API: Получение постов блога
    server.on("/api/getBlogPosts", HTTP_GET, [](AsyncWebServerRequest *request){
        DynamicJsonDocument doc(4096);
        JsonArray posts = doc.createNestedArray("posts");
        
        if (SD.exists("/root/blog/posts.txt")) {
            File blogFile = SD.open("/root/blog/posts.txt");
            if (blogFile) {
                while (blogFile.available()) {
                    String line = blogFile.readStringUntil('\n');
                    line.trim();
                    
                    if (line.length() > 0 && !line.startsWith("#")) {
                        int firstComma = line.indexOf(',');
                        int secondComma = line.indexOf(',', firstComma + 1);
                        int thirdComma = line.indexOf(',', secondComma + 1);
                        
                        if (firstComma > 0 && secondComma > 0 && thirdComma > 0) {
                            JsonObject post = posts.createNestedObject();
                            post["timestamp"] = line.substring(0, firstComma);
                            post["title"] = line.substring(firstComma + 1, secondComma);
                            post["content"] = line.substring(secondComma + 1, thirdComma);
                            post["author"] = line.substring(thirdComma + 1);
                        }
                    }
                }
                blogFile.close();
            }
        }
        
        String responseStr;
        serializeJson(doc, responseStr);
        request->send(200, "application/json", responseStr);
    });
    
    // API: Отправка сообщения в поддержку
    server.on("/api/sendSupportMessage", HTTP_POST, [](AsyncWebServerRequest *request){}, NULL,
        [](AsyncWebServerRequest *request, uint8_t *data, size_t len, size_t index, size_t total){
            DynamicJsonDocument doc(1024);
            deserializeJson(doc, (char*)data);
            
            String username = sanitizeInput(doc["username"]);
            String message = sanitizeInput(doc["message"]);
            
            File supportFile = SD.open("/root/support/tickets.txt", FILE_APPEND);
            if (supportFile) {
                String timestamp = String(millis());
                String line = timestamp + "," + username + "," + message;
                supportFile.println(line);
                supportFile.close();
                
                request->send(200, "application/json", "{\"success\":true}");
            } else {
                request->send(500, "application/json", "{\"success\":false}");
            }
        });
    
    // API: Бан пользователя (только админ)
    server.on("/api/banUser", HTTP_POST, [](AsyncWebServerRequest *request){}, NULL,
        [](AsyncWebServerRequest *request, uint8_t *data, size_t len, size_t index, size_t total){
            DynamicJsonDocument doc(1024);
            deserializeJson(doc, (char*)data);
            
            String targetUsername = sanitizeInput(doc["username"]);
            String duration = sanitizeInput(doc["duration"]);
            String reason = sanitizeInput(doc["reason"]);
            
            // Тут должна быть проверка прав администратора
            // Для упрощения пока пропускаем
            
            for (auto& user : users) {
                if (user.username == targetUsername) {
                    user.isBanned = true;
                    user.banUntil = String(millis() + (duration.toInt() * 60000)); // duration в минутах
                    
                    // Записываем в файл
                    String banFilePath = "/root/users/" + targetUsername + "/ban.txt";
                    File banFile = SD.open(banFilePath, FILE_APPEND);
                    if (banFile) {
                        String timestamp = String(millis());
                        String line = timestamp + "," + duration + "," + reason;
                        banFile.println(line);
                        banFile.close();
                    }
                    
                    request->send(200, "application/json", "{\"success\":true}");
                    return;
                }
            }
            
            request->send(404, "application/json", "{\"success\":false,\"error\":\"User not found\"}");
        });
    
    // API: Статус сервера
    server.on("/api/getServerStatus", HTTP_GET, [](AsyncWebServerRequest *request){
        DynamicJsonDocument doc(512);
        
        // Подсчитываем подключенных пользователей (активные WebSocket соединения)
        doc["connectedUsers"] = webSocket.connectedClients();
        
        // Примерные значения для демонстрации
        doc["cpuUsage"] = random(20, 60);
        doc["memoryUsage"] = random(30, 70);
        doc["activeServers"] = connectedServers.size() + 1; // +1 для текущего сервера
        
        String responseStr;
        serializeJson(doc, responseStr);
        request->send(200, "application/json", responseStr);
    });
    
    // Обработчик 404
    server.onNotFound([](AsyncWebServerRequest *request){
        request->send(404, "text/plain", "Not found");
    });
    
    server.begin();
    Serial.println("Web server started");
}

void loop() {
    // Обработка WebSocket событий
    webSocket.loop();
    
    // Проверка кнопки включения/выключения сервера
    if (digitalRead(BUTTON_PIN) == LOW) {
        delay(50); // Debounce
        if (digitalRead(BUTTON_PIN) == LOW) {
            serverActive = !serverActive;
            Serial.printf("Server %s\n", serverActive ? "enabled" : "disabled");
            
            // Ждем отпускания кнопки
            while (digitalRead(BUTTON_PIN) == LOW) {
                delay(10);
            }
        }
    }
    
    // Периодическая синхронизация с другими серверами
    if (millis() - lastHeartbeat > 30000) { // Каждые 30 секунд
        lastHeartbeat = millis();
        
        // Отправляем heartbeat другим серверам
        DynamicJsonDocument heartbeat(512);
        heartbeat["type"] = "heartbeat";
        heartbeat["serverId"] = serverId;
        heartbeat["timestamp"] = millis();
        heartbeat["connectedUsers"] = webSocket.connectedClients();
        
        String heartbeatStr;
        serializeJson(heartbeat, heartbeatStr);
        
        // Здесь должна быть логика отправки другим серверам
        // Пока что просто выводим в Serial
        Serial.println("Heartbeat: " + heartbeatStr);
    }
    
    delay(10);
}