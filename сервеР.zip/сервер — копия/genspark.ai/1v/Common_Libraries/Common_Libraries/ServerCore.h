#ifndef SERVERCORE_H
#define SERVERCORE_H

#include <WiFi.h>
#include <WebServer.h>
#include <WebSocketsServer.h>
#include <FS.h>
#include <SD.h>
#include <ArduinoJson.h>
#include <ESPAsyncWebServer.h>

// Константы
#define MAX_MESSAGE_LENGTH 100
#define MAX_USERS 50
#define ADMIN_USERNAME "admin"
#define ADMIN_PASSWORD "7428"

// Структуры данных
struct User {
    String username;
    String password;
    bool isAdmin;
    bool isBanned;
    String banUntil;
    String avatarPath;
    unsigned long lastActivity;
};

struct ChatMessage {
    String username;
    String content;
    String messageType; // text, image, file, audio
    String timestamp;
    String filePath;
};

struct ServerInfo {
    String serverId;
    String serverName;
    String ipAddress;
    int connectedUsers;
    bool isActive;
    unsigned long lastPing;
    float cpuUsage;
    float memoryUsage;
    float sdUsage;
};

class ServerCore {
private:
    AsyncWebServer* server;
    WebSocketsServer* webSocket;
    std::vector<User> users;
    std::vector<ChatMessage> chatHistory;
    std::vector<ServerInfo> connectedServers;
    String serverId;
    bool isMainServer;
    
public:
    ServerCore(int port = 80);
    ~ServerCore();
    
    // Инициализация
    bool initSD();
    bool initWiFi(const char* ssid, const char* password, bool isAP = false);
    bool initFileSystem();
    void setupRoutes();
    
    // Управление пользователями
    bool authenticateUser(const String& username, const String& password);
    bool registerUser(const String& username, const String& password);
    bool banUser(const String& username, const String& duration, const String& reason);
    bool unbanUser(const String& username);
    User* getUser(const String& username);
    std::vector<User> getAllUsers();
    
    // Чат система
    bool sendMessage(const String& username, const String& content, const String& messageType = "text");
    std::vector<ChatMessage> getChatHistory(int limit = 50);
    bool deleteMessage(int messageId);
    
    // Файловая система
    String uploadFile(const String& filename, const uint8_t* data, size_t length);
    bool deleteFile(const String& filepath);
    std::vector<String> listFiles(const String& directory);
    
    // Безопасность
    bool checkRateLimit(const String& clientIP);
    String sanitizeInput(const String& input);
    bool isValidSession(const String& sessionId);
    String generateSessionId();
    
    // Синхронизация серверов
    bool connectToServer(const String& serverIP);
    bool syncWithServers();
    void broadcastToServers(const String& message);
    std::vector<ServerInfo> getServerList();
    
    // Мониторинг
    ServerInfo getServerStatus();
    void logActivity(const String& action, const String& details);
    
    // Блог система
    bool createBlogPost(const String& title, const String& content, const String& author);
    std::vector<String> getBlogPosts();
    bool deleteBlogPost(int postId);
    
    // Техподдержка
    bool createSupportTicket(const String& username, const String& message);
    std::vector<String> getSupportTickets();
    bool respondToTicket(int ticketId, const String& response);
    
    // Утилиты
    void startServer();
    void handleClient();
    void update();
    bool isSDCardPresent();
    void createDefaultDirectories();
};

// Глобальные функции защиты
bool protectAgainstDoS(const String& clientIP, unsigned long currentTime);
String escapeHTML(const String& input);
bool validateCSRFToken(const String& token, const String& sessionId);
String generateCSRFToken(const String& sessionId);

#endif