#include <Arduino.h>
#include <WiFi.h>
#include <ESPAsyncWebServer.h>
#include <WebSocketsServer.h>
#include <ArduinoJson.h>
#include <ESPmDNS.h>

// M5Stamp S3 - только серверные функции, без интерфейса
// Светодиод для индикации статуса
#define STATUS_LED 21

// Глобальные объекты
AsyncWebServer server(80);
WebSocketsServer webSocket = WebSocketsServer(81);

// Переменные состояния
bool serverActive = false;
bool isConnectedToMainServer = false;
String mainServerIP = "";
String serverId = "stamp-s3";

// Статистика
int connectedClients = 0;
unsigned long lastHeartbeat = 0;

void setup() {
    Serial.begin(115200);
    Serial.println("M5Stamp S3 Server starting...");
    
    // Инициализация LED
    pinMode(STATUS_LED, OUTPUT);
    digitalWrite(STATUS_LED, LOW);
    
    // Поиск главного сервера
    searchForMainServer();
    
    if (!isConnectedToMainServer) {
        // Запускаем автономный сервер
        startAutonomousServer();
    }
    
    Serial.println("M5Stamp S3 ready");
}

void searchForMainServer() {
    Serial.println("Searching for main server...");
    
    int networksFound = WiFi.scanNetworks();
    
    for (int i = 0; i < networksFound; i++) {
        String ssid = WiFi.SSID(i);
        if (ssid.startsWith("ESP32-ChatServer")) {
            Serial.printf("Found server: %s\n", ssid.c_str());
            
            WiFi.begin(ssid.c_str(), "12345678");
            
            int attempts = 0;
            while (WiFi.status() != WL_CONNECTED && attempts < 20) {
                delay(500);
                attempts++;
                digitalWrite(STATUS_LED, !digitalRead(STATUS_LED)); // Мигаем при подключении
            }
            
            if (WiFi.status() == WL_CONNECTED) {
                mainServerIP = WiFi.gatewayIP().toString();
                isConnectedToMainServer = true;
                digitalWrite(STATUS_LED, HIGH); // Постоянно горит при подключении
                
                Serial.printf("Connected to main server: %s\n", mainServerIP.c_str());
                
                // Регистрируемся как дочерний сервер
                registerWithMainServer();
                return;
            }
        }
    }
    
    digitalWrite(STATUS_LED, LOW); // Выключен если не подключен
}

void startAutonomousServer() {
    Serial.println("Starting autonomous mode");
    
    // Запускаем точку доступа
    WiFi.mode(WIFI_AP);
    WiFi.softAP("ESP32-Stamp-S3", "12345678");
    
    IPAddress IP = WiFi.softAPIP();
    Serial.printf("AP IP: %s\n", IP.toString().c_str());
    
    // Настройка MDNS
    if (MDNS.begin("esp32-stamp")) {
        MDNS.addService("http", "tcp", 80);
    }
    
    // Настройка веб-сервера
    setupWebServer();
    
    // Запуск WebSocket сервера
    webSocket.begin();
    webSocket.onEvent(webSocketEvent);
    
    serverActive = true;
    digitalWrite(STATUS_LED, HIGH);
    
    Serial.println("Autonomous server started");
}

void registerWithMainServer() {
    // HTTP запрос для регистрации в главном сервере
    // Здесь должна быть логика регистрации дочернего сервера
    Serial.println("Registering with main server...");
}

void setupWebServer() {
    // Основные API эндпоинты для дочернего сервера
    server.on("/api/status", HTTP_GET, [](AsyncWebServerRequest *request){
        DynamicJsonDocument doc(512);
        doc["serverId"] = serverId;
        doc["type"] = "stamp-s3";
        doc["connectedClients"] = connectedClients;
        doc["freeHeap"] = ESP.getFreeHeap();
        doc["uptime"] = millis();
        
        String response;
        serializeJson(doc, response);
        request->send(200, "application/json", response);
    });
    
    server.on("/api/sync", HTTP_POST, [](AsyncWebServerRequest *request){}, NULL,
        [](AsyncWebServerRequest *request, uint8_t *data, size_t len, size_t index, size_t total){
            // Обработка синхронизации данных
            DynamicJsonDocument doc(2048);
            deserializeJson(doc, (char*)data);
            
            String syncType = doc["type"];
            if (syncType == "chat_sync") {
                // Обработка синхронизации чата
                Serial.println("Chat sync received");
            }
            
            request->send(200, "application/json", "{\"success\":true}");
        });
    
    server.begin();
}

void webSocketEvent(uint8_t num, WStype_t type, uint8_t * payload, size_t length) {
    switch(type) {
        case WStype_DISCONNECTED:
            Serial.printf("[%u] Disconnected!\n", num);
            connectedClients--;
            break;
            
        case WStype_CONNECTED: {
            IPAddress ip = webSocket.remoteIP(num);
            Serial.printf("[%u] Connected from %d.%d.%d.%d\n", num, ip[0], ip[1], ip[2], ip[3]);
            connectedClients++;
            break;
        }
        
        case WStype_TEXT: {
            Serial.printf("[%u] Received: %s\n", num, payload);
            
            // Парсим и обрабатываем сообщение
            DynamicJsonDocument doc(1024);
            deserializeJson(doc, payload);
            
            String msgType = doc["type"];
            if (msgType == "ping") {
                webSocket.sendTXT(num, "{\"type\":\"pong\"}");
            } else if (msgType == "relay") {
                // Ретранслируем сообщение другим клиентам
                webSocket.broadcastTXT((char*)payload);
            }
            break;
        }
        
        default:
            break;
    }
}

void loop() {
    // Обработка WebSocket событий
    if (serverActive) {
        webSocket.loop();
    }
    
    // Периодическая отправка heartbeat главному серверу
    if (isConnectedToMainServer && millis() - lastHeartbeat > 30000) {
        lastHeartbeat = millis();
        sendHeartbeat();
    }
    
    // Моргаем светодиодом для индикации активности
    static unsigned long lastBlink = 0;
    if (millis() - lastBlink > 2000) {
        lastBlink = millis();
        if (serverActive) {
            digitalWrite(STATUS_LED, !digitalRead(STATUS_LED));
        }
    }
    
    // Если потеряли соединение с главным сервером, переходим в автономный режим
    if (isConnectedToMainServer && WiFi.status() != WL_CONNECTED) {
        Serial.println("Lost connection to main server");
        isConnectedToMainServer = false;
        if (!serverActive) {
            startAutonomousServer();
        }
    }
    
    delay(10);
}

void sendHeartbeat() {
    // Отправка статуса главному серверу
    DynamicJsonDocument doc(512);
    doc["type"] = "heartbeat";
    doc["serverId"] = serverId;
    doc["timestamp"] = millis();
    doc["connectedClients"] = connectedClients;
    doc["freeHeap"] = ESP.getFreeHeap();
    
    String heartbeatStr;
    serializeJson(doc, heartbeatStr);
    
    // Здесь должна быть отправка HTTP запроса главному серверу
    Serial.println("Heartbeat: " + heartbeatStr);
}