#include <Arduino.h>
#include <WiFi.h>
#include <WebSocketsClient.h>
#include <ArduinoJson.h>
#include <HTTPClient.h>
#include <SD.h>
#include <FS.h>
#include <SPI.h>
#include <TFT_eSPI.h>
#include <lvgl.h>

// Настройки дисплея
#define SCREEN_WIDTH 320
#define SCREEN_HEIGHT 240
#define LVGL_BUFFER_SIZE (SCREEN_WIDTH * SCREEN_HEIGHT / 10)

// Настройки SD карты (обязательно для M5Tab)
#define SD_CS_PIN 4
#define SD_MOSI_PIN 23
#define SD_MISO_PIN 19
#define SD_SCK_PIN 18

// Пины сенсорного экрана
#define TOUCH_CS 21
#define TOUCH_IRQ 39

// Режимы работы
enum TabMode {
    TAB_LOGIN,
    TAB_CHAT,
    TAB_BLOG,
    TAB_SERVER,
    TAB_SUPPORT
};

// Глобальные объекты
TFT_eSPI tft = TFT_eSPI();
WebSocketsClient webSocket;
HTTPClient http;

// LVGL буферы
static lv_disp_draw_buf_t draw_buf;
static lv_color_t buf[LVGL_BUFFER_SIZE];

// Переменные состояния
TabMode currentMode = TAB_LOGIN;
String currentUser = "";
bool isLoggedIn = false;
bool isServerConnected = false;
bool sdCardReady = false;

String mainServerIP = "";
std::vector<String> chatMessages;
std::vector<String> blogPosts;
std::vector<String> supportTickets;

// UI элементы
lv_obj_t * main_tabview;
lv_obj_t * chat_tab;
lv_obj_t * blog_tab;
lv_obj_t * server_tab;
lv_obj_t * support_tab;

lv_obj_t * chat_textarea;
lv_obj_t * chat_input;
lv_obj_t * chat_send_btn;
lv_obj_t * file_upload_btn;

lv_obj_t * blog_list;
lv_obj_t * server_stats_label;
lv_obj_t * support_input;
lv_obj_t * support_send_btn;

// Серверная статистика
struct ServerStats {
    int connectedUsers;
    float cpuUsage;
    float memoryUsage;
    int activeServers;
    String status;
    float sdUsage;
};

ServerStats serverStats;

// Функции LVGL
void my_disp_flush(lv_disp_drv_t *disp, const lv_area_t *area, lv_color_t *color_p) {
    uint32_t w = (area->x2 - area->x1 + 1);
    uint32_t h = (area->y2 - area->y1 + 1);

    tft.startWrite();
    tft.setAddrWindow(area->x1, area->y1, w, h);
    tft.pushColors((uint16_t*)&color_p->full, w * h, true);
    tft.endWrite();

    lv_disp_flush_ready(disp);
}

bool my_touchpad_read(lv_indev_drv_t * indev_driver, lv_indev_data_t * data) {
    uint16_t touchX, touchY;
    
    bool touched = tft.getTouch(&touchX, &touchY);
    
    if (touched) {
        data->state = LV_INDEV_STATE_PR;
        data->point.x = touchX;
        data->point.y = touchY;
    } else {
        data->state = LV_INDEV_STATE_REL;
    }
    
    return false;
}

void setup() {
    Serial.begin(115200);
    Serial.println("M5Tab Chat Client starting...");
    
    // Инициализация дисплея
    tft.init();
    tft.setRotation(1);
    tft.fillScreen(TFT_BLACK);
    
    // Инициализация SD карты (обязательно!)
    SPI.begin(SD_SCK_PIN, SD_MISO_PIN, SD_MOSI_PIN, SD_CS_PIN);
    
    if (!SD.begin(SD_CS_PIN)) {
        Serial.println("SD Card initialization failed!");
        tft.setTextColor(TFT_RED);
        tft.drawString("SD ERROR! Need 2GB+ SD card", 10, 10, 2);
        while(1) {
            delay(1000);
        }
    }
    
    // Проверяем размер SD карты
    uint64_t cardSize = SD.cardSize() / (1024 * 1024);
    Serial.printf("SD Card Size: %lluMB\n", cardSize);
    
    if (cardSize < 2048) {
        Serial.println("SD Card too small! Need at least 2GB");
        tft.setTextColor(TFT_RED);
        tft.drawString("SD too small! Need 2GB+", 10, 30, 2);
        while(1) {
            delay(1000);
        }
    }
    
    sdCardReady = true;
    
    // Создаем файловую структуру на SD карте
    createSDStructure();
    
    // Инициализация LVGL
    lv_init();
    
    lv_disp_draw_buf_init(&draw_buf, buf, NULL, LVGL_BUFFER_SIZE);
    
    static lv_disp_drv_t disp_drv;
    lv_disp_drv_init(&disp_drv);
    disp_drv.hor_res = SCREEN_WIDTH;
    disp_drv.ver_res = SCREEN_HEIGHT;
    disp_drv.flush_cb = my_disp_flush;
    disp_drv.draw_buf = &draw_buf;
    lv_disp_drv_register(&disp_drv);
    
    // Инициализация сенсорного ввода
    static lv_indev_drv_t indev_drv;
    lv_indev_drv_init(&indev_drv);
    indev_drv.type = LV_INDEV_TYPE_POINTER;
    indev_drv.read_cb = my_touchpad_read;
    lv_indev_drv_register(&indev_drv);
    
    // Поиск и подключение к серверу
    searchForServer();
    
    // Создание пользовательского интерфейса
    createUI();
    
    Serial.println("M5Tab initialized successfully");
}

void createSDStructure() {
    // Создаем необходимые директории на SD карте
    SD.mkdir("/root");
    SD.mkdir("/root/users");
    SD.mkdir("/root/chat");
    SD.mkdir("/root/chat/files");
    SD.mkdir("/root/chat/images");
    SD.mkdir("/root/chat/audio");
    SD.mkdir("/root/blog");
    SD.mkdir("/root/support");
    SD.mkdir("/root/logs");
    SD.mkdir("/root/config");
    SD.mkdir("/root/files");
    SD.mkdir("/root/temp");
    
    // Создаем файл конфигурации если его нет
    if (!SD.exists("/root/config/m5tab.conf")) {
        File configFile = SD.open("/root/config/m5tab.conf", FILE_WRITE);
        if (configFile) {
            configFile.println("# M5Tab Configuration");
            configFile.println("device_type=m5tab");
            configFile.println("server_mode=true");
            configFile.println("auto_sync=true");
            configFile.close();
        }
    }
}

void searchForServer() {
    tft.fillScreen(TFT_BLACK);
    tft.setTextColor(TFT_CYAN);
    tft.drawString("Поиск сервера...", 10, 10, 2);
    
    // Сканируем WiFi сети
    int networksFound = WiFi.scanNetworks();
    
    for (int i = 0; i < networksFound; i++) {
        String ssid = WiFi.SSID(i);
        if (ssid.startsWith("ESP32-ChatServer") || ssid.startsWith("ESP32-")) {
            tft.drawString("Найден: " + ssid, 10, 30 + (i * 20), 1);
            
            // Пытаемся подключиться
            WiFi.begin(ssid.c_str(), "12345678");
            
            int attempts = 0;
            while (WiFi.status() != WL_CONNECTED && attempts < 20) {
                delay(500);
                attempts++;
            }
            
            if (WiFi.status() == WL_CONNECTED) {
                mainServerIP = WiFi.gatewayIP().toString();
                isServerConnected = true;
                
                tft.setTextColor(TFT_GREEN);
                tft.drawString("Подключено к: " + mainServerIP, 10, 100, 2);
                
                // Подключаемся к WebSocket
                connectWebSocket();
                break;
            }
        }
    }
    
    if (!isServerConnected) {
        tft.setTextColor(TFT_RED);
        tft.drawString("Сервер не найден!", 10, 120, 2);
        tft.drawString("Автономный режим", 10, 140, 2);
        
        // Запускаем собственный сервер
        startAutonomousMode();
    }
    
    delay(2000);
}

void startAutonomousMode() {
    // В автономном режиме M5Tab становится сервером
    WiFi.mode(WIFI_AP);
    WiFi.softAP("ESP32-M5Tab", "12345678");
    
    IPAddress IP = WiFi.softAPIP();
    Serial.print("M5Tab AP IP: ");
    Serial.println(IP);
    
    // Записываем в логи
    logToSD("M5Tab started in autonomous mode. IP: " + IP.toString());
}

void connectWebSocket() {
    webSocket.begin(mainServerIP, 81, "/");
    webSocket.onEvent(webSocketEvent);
    webSocket.setReconnectInterval(5000);
}

void webSocketEvent(WStype_t type, uint8_t * payload, size_t length) {
    switch(type) {
        case WStype_DISCONNECTED:
            Serial.println("WebSocket Disconnected");
            isServerConnected = false;
            break;
            
        case WStype_CONNECTED:
            Serial.printf("WebSocket Connected to: %s\n", payload);
            isServerConnected = true;
            break;
            
        case WStype_TEXT: {
            String message = String((char*)payload);
            DynamicJsonDocument doc(1024);
            deserializeJson(doc, message);
            
            handleWebSocketMessage(doc);
            break;
        }
        
        default:
            break;
    }
}

void handleWebSocketMessage(DynamicJsonDocument& doc) {
    String msgType = doc["type"];
    
    if (msgType == "new_message") {
        String username = doc["username"];
        String content = doc["content"];
        String messageType = doc["messageType"];
        
        String fullMessage = username + ": " + content;
        chatMessages.push_back(fullMessage);
        
        // Сохраняем на SD карту
        saveChatMessageToSD(username, content, messageType);
        
        // Ограничиваем количество сообщений в памяти
        if (chatMessages.size() > 50) {
            chatMessages.erase(chatMessages.begin());
        }
        
        // Обновляем UI если находимся в чате
        if (currentMode == TAB_CHAT) {
            updateChatUI();
        }
    }
}

void createUI() {
    // Создаем основной tabview
    main_tabview = lv_tabview_create(lv_scr_act(), LV_DIR_TOP, 40);
    
    // Создаем вкладки
    chat_tab = lv_tabview_add_tab(main_tabview, "ЧАТ");
    blog_tab = lv_tabview_add_tab(main_tabview, "БЛОГ");
    server_tab = lv_tabview_add_tab(main_tabview, "СЕРВЕР");
    support_tab = lv_tabview_add_tab(main_tabview, "ПОДДЕРЖКА");
    
    // Настраиваем вкладку чата
    setupChatTab();
    
    // Настраиваем вкладку блога
    setupBlogTab();
    
    // Настраиваем вкладку сервера
    setupServerTab();
    
    // Настраиваем вкладку поддержки
    setupSupportTab();
    
    // Обработчик переключения вкладок
    lv_obj_add_event_cb(main_tabview, tab_changed_event_cb, LV_EVENT_VALUE_CHANGED, NULL);
}

void setupChatTab() {
    // Текстовая область для сообщений
    chat_textarea = lv_textarea_create(chat_tab);
    lv_obj_set_size(chat_textarea, 300, 140);
    lv_obj_align(chat_textarea, LV_ALIGN_TOP_MID, 0, 10);
    lv_textarea_set_placeholder_text(chat_textarea, "Сообщения чата...");
    lv_obj_add_state(chat_textarea, LV_STATE_DISABLED);
    
    // Поле ввода сообщения
    chat_input = lv_textarea_create(chat_tab);
    lv_obj_set_size(chat_input, 200, 40);
    lv_obj_align(chat_input, LV_ALIGN_BOTTOM_LEFT, 10, -10);
    lv_textarea_set_placeholder_text(chat_input, "Введите сообщение...");
    lv_textarea_set_max_length(chat_input, 100);
    lv_textarea_set_one_line(chat_input, true);
    
    // Кнопка отправки
    chat_send_btn = lv_btn_create(chat_tab);
    lv_obj_set_size(chat_send_btn, 80, 40);
    lv_obj_align(chat_send_btn, LV_ALIGN_BOTTOM_RIGHT, -10, -10);
    lv_obj_add_event_cb(chat_send_btn, send_message_event_cb, LV_EVENT_CLICKED, NULL);
    
    lv_obj_t * send_label = lv_label_create(chat_send_btn);
    lv_label_set_text(send_label, "Отправить");
    lv_obj_center(send_label);
    
    // Кнопка загрузки файла
    file_upload_btn = lv_btn_create(chat_tab);
    lv_obj_set_size(file_upload_btn, 70, 30);
    lv_obj_align(file_upload_btn, LV_ALIGN_BOTTOM_MID, 0, -50);
    lv_obj_add_event_cb(file_upload_btn, upload_file_event_cb, LV_EVENT_CLICKED, NULL);
    
    lv_obj_t * upload_label = lv_label_create(file_upload_btn);
    lv_label_set_text(upload_label, "Файл");
    lv_obj_center(upload_label);
}

void setupBlogTab() {
    // Список блог-постов
    blog_list = lv_list_create(blog_tab);
    lv_obj_set_size(blog_list, 300, 170);
    lv_obj_align(blog_list, LV_ALIGN_TOP_MID, 0, 10);
    
    // Загружаем посты при создании
    loadBlogPosts();
}

void setupServerTab() {
    // Статистика сервера
    server_stats_label = lv_label_create(server_tab);
    lv_obj_set_size(server_stats_label, 300, 170);
    lv_obj_align(server_stats_label, LV_ALIGN_TOP_MID, 0, 10);
    lv_label_set_text(server_stats_label, "Загрузка статистики...");
    
    updateServerStats();
}

void setupSupportTab() {
    // Поле ввода обращения
    support_input = lv_textarea_create(support_tab);
    lv_obj_set_size(support_input, 300, 100);
    lv_obj_align(support_input, LV_ALIGN_TOP_MID, 0, 10);
    lv_textarea_set_placeholder_text(support_input, "Опишите вашу проблему...");
    
    // Кнопка отправки обращения
    support_send_btn = lv_btn_create(support_tab);
    lv_obj_set_size(support_send_btn, 150, 40);
    lv_obj_align(support_send_btn, LV_ALIGN_TOP_MID, 0, 120);
    lv_obj_add_event_cb(support_send_btn, send_support_event_cb, LV_EVENT_CLICKED, NULL);
    
    lv_obj_t * support_label = lv_label_create(support_send_btn);
    lv_label_set_text(support_label, "Отправить админу");
    lv_obj_center(support_label);
}

// Обработчики событий
static void tab_changed_event_cb(lv_event_t * e) {
    lv_obj_t * tabview = lv_event_get_target(e);
    uint32_t tab_id = lv_tabview_get_tab_act(tabview);
    
    switch(tab_id) {
        case 0: // Чат
            currentMode = TAB_CHAT;
            loadChatHistory();
            break;
        case 1: // Блог
            currentMode = TAB_BLOG;
            loadBlogPosts();
            break;
        case 2: // Сервер
            currentMode = TAB_SERVER;
            updateServerStats();
            break;
        case 3: // Поддержка
            currentMode = TAB_SUPPORT;
            break;
    }
}

static void send_message_event_cb(lv_event_t * e) {
    const char * message_text = lv_textarea_get_text(chat_input);
    
    if (strlen(message_text) > 0) {
        sendChatMessage(String(message_text));
        lv_textarea_set_text(chat_input, "");
    }
}

static void upload_file_event_cb(lv_event_t * e) {
    // Здесь должна быть логика выбора и загрузки файла с SD карты
    // Для упрощения отправляем уведомление
    sendChatMessage("[Файл загружен с SD карты]");
}

static void send_support_event_cb(lv_event_t * e) {
    const char * support_text = lv_textarea_get_text(support_input);
    
    if (strlen(support_text) > 0) {
        sendSupportMessage(String(support_text));
        lv_textarea_set_text(support_input, "");
        
        // Показываем уведомление
        lv_obj_t * mbox = lv_msgbox_create(NULL, "Готово", "Обращение отправлено администратору", NULL, true);
        lv_obj_center(mbox);
    }
}

void sendChatMessage(String message) {
    if (!isServerConnected) {
        // Сохраняем на SD карту для последующей синхронизации
        saveChatMessageToSD(currentUser, message, "text");
        return;
    }
    
    DynamicJsonDocument doc(512);
    doc["type"] = "chat_message";
    doc["username"] = currentUser;
    doc["message"] = message;
    doc["messageType"] = "text";
    
    String jsonString;
    serializeJson(doc, jsonString);
    
    webSocket.sendTXT(jsonString);
    
    // Также сохраняем на SD карту
    saveChatMessageToSD(currentUser, message, "text");
}

void sendSupportMessage(String message) {
    if (isServerConnected) {
        HTTPClient http;
        http.begin("http://" + mainServerIP + "/api/sendSupportMessage");
        http.addHeader("Content-Type", "application/json");
        
        DynamicJsonDocument doc(512);
        doc["username"] = currentUser;
        doc["message"] = message;
        
        String jsonString;
        serializeJson(doc, jsonString);
        
        int httpResponseCode = http.POST(jsonString);
        http.end();
    }
    
    // Сохраняем на SD карту
    saveSupportMessageToSD(currentUser, message);
}

void loadChatHistory() {
    if (isServerConnected) {
        HTTPClient http;
        http.begin("http://" + mainServerIP + "/api/getChatHistory");
        
        int httpResponseCode = http.GET();
        
        if (httpResponseCode == 200) {
            String response = http.getString();
            
            DynamicJsonDocument doc(4096);
            deserializeJson(doc, response);
            
            JsonArray messages = doc["messages"];
            chatMessages.clear();
            
            for (JsonObject message : messages) {
                String username = message["username"];
                String content = message["content"];
                String fullMessage = username + ": " + content;
                chatMessages.push_back(fullMessage);
            }
            
            updateChatUI();
        }
        
        http.end();
    } else {
        // Загружаем из SD карты
        loadChatFromSD();
    }
}

void loadBlogPosts() {
    if (isServerConnected) {
        HTTPClient http;
        http.begin("http://" + mainServerIP + "/api/getBlogPosts");
        
        int httpResponseCode = http.GET();
        
        if (httpResponseCode == 200) {
            String response = http.getString();
            
            DynamicJsonDocument doc(4096);
            deserializeJson(doc, response);
            
            JsonArray posts = doc["posts"];
            blogPosts.clear();
            
            for (JsonObject post : posts) {
                String title = post["title"];
                String author = post["author"];
                String content = post["content"];
                String fullPost = title + "\n" + content + "\n- " + author;
                blogPosts.push_back(fullPost);
            }
            
            updateBlogUI();
        }
        
        http.end();
    } else {
        // Загружаем из SD карты
        loadBlogFromSD();
    }
}

void updateServerStats() {
    if (isServerConnected) {
        HTTPClient http;
        http.begin("http://" + mainServerIP + "/api/getServerStatus");
        
        int httpResponseCode = http.GET();
        
        if (httpResponseCode == 200) {
            String response = http.getString();
            
            DynamicJsonDocument doc(1024);
            deserializeJson(doc, response);
            
            serverStats.connectedUsers = doc["connectedUsers"];
            serverStats.cpuUsage = doc["cpuUsage"];
            serverStats.memoryUsage = doc["memoryUsage"];
            serverStats.activeServers = doc["activeServers"];
        }
        
        http.end();
    }
    
    // Получаем информацию о SD карте
    uint64_t cardSize = SD.cardSize() / (1024 * 1024);
    uint64_t usedSize = SD.usedBytes() / (1024 * 1024);
    serverStats.sdUsage = (float)usedSize / cardSize * 100.0;
    
    // Обновляем UI
    String statsText = "=== СТАТИСТИКА M5TAB ===\n\n";
    
    if (isServerConnected) {
        statsText += "Статус: Подключен к серверу\n";
        statsText += "IP сервера: " + mainServerIP + "\n";
        statsText += "Пользователей: " + String(serverStats.connectedUsers) + "\n";
        statsText += "CPU: " + String(serverStats.cpuUsage, 1) + "%\n";
        statsText += "RAM: " + String(serverStats.memoryUsage, 1) + "%\n";
        statsText += "Серверов: " + String(serverStats.activeServers) + "\n";
    } else {
        statsText += "Статус: Автономный режим\n";
        statsText += "Режим: Сервер\n";
    }
    
    statsText += "\n=== ЛОКАЛЬНОЕ ХРАНИЛИЩЕ ===\n";
    statsText += "SD карта: " + String(cardSize) + " МБ\n";
    statsText += "Использовано: " + String(usedSize) + " МБ\n";
    statsText += "Заполнено: " + String(serverStats.sdUsage, 1) + "%\n";
    
    statsText += "\n=== СЕТЕВОЕ ПОДКЛЮЧЕНИЕ ===\n";
    if (WiFi.status() == WL_CONNECTED) {
        statsText += "WiFi: Подключен\n";
        statsText += "IP: " + WiFi.localIP().toString() + "\n";
        statsText += "RSSI: " + String(WiFi.RSSI()) + " dBm\n";
    } else {
        statsText += "WiFi: Отключен\n";
    }
    
    lv_label_set_text(server_stats_label, statsText.c_str());
}

void updateChatUI() {
    String chatText = "";
    for (const auto& message : chatMessages) {
        chatText += message + "\n";
    }
    lv_textarea_set_text(chat_textarea, chatText.c_str());
    
    // Прокручиваем вниз
    lv_textarea_set_cursor_pos(chat_textarea, LV_TEXTAREA_CURSOR_LAST);
}

void updateBlogUI() {
    // Очищаем список
    lv_obj_clean(blog_list);
    
    // Добавляем посты
    for (const auto& post : blogPosts) {
        lv_obj_t * btn = lv_list_add_btn(blog_list, LV_SYMBOL_FILE, post.c_str());
        lv_obj_set_style_text_align(btn, LV_TEXT_ALIGN_LEFT, 0);
    }
}

// Функции работы с SD картой
void saveChatMessageToSD(String username, String content, String messageType) {
    if (!sdCardReady) return;
    
    File chatFile = SD.open("/root/chat/messages.txt", FILE_APPEND);
    if (chatFile) {
        String timestamp = String(millis());
        String line = timestamp + "," + username + "," + messageType + "," + content;
        chatFile.println(line);
        chatFile.close();
    }
}

void saveSupportMessageToSD(String username, String message) {
    if (!sdCardReady) return;
    
    File supportFile = SD.open("/root/support/tickets.txt", FILE_APPEND);
    if (supportFile) {
        String timestamp = String(millis());
        String line = timestamp + "," + username + "," + message;
        supportFile.println(line);
        supportFile.close();
    }
}

void loadChatFromSD() {
    if (!sdCardReady) return;
    
    chatMessages.clear();
    
    if (SD.exists("/root/chat/messages.txt")) {
        File chatFile = SD.open("/root/chat/messages.txt");
        if (chatFile) {
            while (chatFile.available()) {
                String line = chatFile.readStringUntil('\n');
                line.trim();
                
                if (line.length() > 0 && !line.startsWith("#")) {
                    // Парсим: timestamp,username,message_type,content
                    int firstComma = line.indexOf(',');
                    int secondComma = line.indexOf(',', firstComma + 1);
                    int thirdComma = line.indexOf(',', secondComma + 1);
                    
                    if (firstComma > 0 && secondComma > 0 && thirdComma > 0) {
                        String username = line.substring(firstComma + 1, secondComma);
                        String content = line.substring(thirdComma + 1);
                        String fullMessage = username + ": " + content;
                        chatMessages.push_back(fullMessage);
                    }
                }
            }
            chatFile.close();
            updateChatUI();
        }
    }
}

void loadBlogFromSD() {
    if (!sdCardReady) return;
    
    blogPosts.clear();
    
    if (SD.exists("/root/blog/posts.txt")) {
        File blogFile = SD.open("/root/blog/posts.txt");
        if (blogFile) {
            while (blogFile.available()) {
                String line = blogFile.readStringUntil('\n');
                line.trim();
                
                if (line.length() > 0 && !line.startsWith("#")) {
                    // Парсим: timestamp,title,content,author
                    int firstComma = line.indexOf(',');
                    int secondComma = line.indexOf(',', firstComma + 1);
                    int thirdComma = line.indexOf(',', secondComma + 1);
                    
                    if (firstComma > 0 && secondComma > 0 && thirdComma > 0) {
                        String title = line.substring(firstComma + 1, secondComma);
                        String content = line.substring(secondComma + 1, thirdComma);
                        String author = line.substring(thirdComma + 1);
                        String fullPost = title + "\n" + content + "\n- " + author;
                        blogPosts.push_back(fullPost);
                    }
                }
            }
            blogFile.close();
            updateBlogUI();
        }
    }
}

void logToSD(String message) {
    if (!sdCardReady) return;
    
    File logFile = SD.open("/root/logs/system.log", FILE_APPEND);
    if (logFile) {
        String timestamp = String(millis());
        logFile.println(timestamp + ": " + message);
        logFile.close();
    }
}

void loop() {
    // Обновляем LVGL
    lv_timer_handler();
    
    // Обновляем WebSocket
    if (isServerConnected) {
        webSocket.loop();
    }
    
    // Периодически обновляем статистику сервера
    static unsigned long lastStatsUpdate = 0;
    if (millis() - lastStatsUpdate > 5000) { // Каждые 5 секунд
        lastStatsUpdate = millis();
        
        if (currentMode == TAB_SERVER) {
            updateServerStats();
        }
        
        // Проверяем подключение к серверу
        if (!isServerConnected) {
            searchForServer();
        }
    }
    
    delay(5);
}