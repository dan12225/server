#include <Arduino.h>
#include <TFT_eSPI.h>
#include <WiFi.h>
#include <WebSocketsClient.h>
#include <ArduinoJson.h>
#include <HTTPClient.h>
#include <SD.h>
#include <Encoder.h>

// Настройки дисплея T-Embed
#define SCREEN_WIDTH 170
#define SCREEN_HEIGHT 320

// Пины энкодера и кнопок
#define ENCODER_PIN_A 2
#define ENCODER_PIN_B 3
#define ENCODER_BUTTON 0
#define SIDE_BUTTON 21

// SD карта
#define SD_CS 10

// Режимы работы
enum EmbedMode {
    MODE_LOGIN,
    MODE_CHAT,
    MODE_BLOG,
    MODE_SERVER,
    MODE_SUPPORT
};

// Глобальные объекты
TFT_eSPI tft = TFT_eSPI();
Encoder encoder(ENCODER_PIN_A, ENCODER_PIN_B);
WebSocketsClient webSocket;

// Переменные состояния
EmbedMode currentMode = MODE_LOGIN;
String currentUser = "";
bool isLoggedIn = false;
bool isServerConnected = false;
bool sdCardReady = false;

String mainServerIP = "";
std::vector<String> chatMessages;
std::vector<String> blogPosts;

int menuSelection = 0;
int scrollPosition = 0;
String inputText = "";
bool isInputMode = false;

long encoderPosition = 0;
unsigned long lastButtonPress = 0;

void setup() {
    Serial.begin(115200);
    Serial.println("LILYGO T-Embed CC1101 starting...");
    
    // Инициализация дисплея
    tft.init();
    tft.setRotation(0); // Портретная ориентация
    tft.fillScreen(TFT_BLACK);
    tft.setTextSize(1);
    tft.setTextColor(TFT_WHITE);
    
    // Инициализация кнопок
    pinMode(ENCODER_BUTTON, INPUT_PULLUP);
    pinMode(SIDE_BUTTON, INPUT_PULLUP);
    
    // Инициализация SD карты
    if (SD.begin(SD_CS)) {
        sdCardReady = true;
        createSDStructure();
        Serial.println("SD Card ready");
    } else {
        Serial.println("SD Card failed - device will not start");
        showError("SD Card Error!\nNeed 2GB+ SD card");
        while(1) delay(1000);
    }
    
    // Поиск сервера
    searchForServer();
    
    // Показать главное меню
    showMainMenu();
    
    Serial.println("T-Embed initialized");
}

void createSDStructure() {
    SD.mkdir("/root");
    SD.mkdir("/root/chat");
    SD.mkdir("/root/blog");
    SD.mkdir("/root/support");
    SD.mkdir("/root/logs");
    SD.mkdir("/root/config");
}

void searchForServer() {
    showStatus("Поиск сервера...");
    
    int networksFound = WiFi.scanNetworks();
    
    for (int i = 0; i < networksFound; i++) {
        String ssid = WiFi.SSID(i);
        if (ssid.startsWith("ESP32-")) {
            showStatus("Подключение к:\n" + ssid);
            
            WiFi.begin(ssid.c_str(), "12345678");
            
            int attempts = 0;
            while (WiFi.status() != WL_CONNECTED && attempts < 20) {
                delay(500);
                attempts++;
            }
            
            if (WiFi.status() == WL_CONNECTED) {
                mainServerIP = WiFi.gatewayIP().toString();
                isServerConnected = true;
                
                showStatus("Подключено к:\n" + mainServerIP);
                connectWebSocket();
                delay(1500);
                return;
            }
        }
    }
    
    showStatus("Сервер не найден\nАвтономный режим");
    startAutonomousMode();
    delay(1500);
}

void startAutonomousMode() {
    WiFi.mode(WIFI_AP);
    WiFi.softAP("ESP32-T-Embed", "12345678");
    Serial.println("Started autonomous AP mode");
}

void connectWebSocket() {
    webSocket.begin(mainServerIP, 81, "/");
    webSocket.onEvent(webSocketEvent);
}

void webSocketEvent(WStype_t type, uint8_t * payload, size_t length) {
    switch(type) {
        case WStype_DISCONNECTED:
            isServerConnected = false;
            break;
            
        case WStype_CONNECTED:
            isServerConnected = true;
            break;
            
        case WStype_TEXT: {
            DynamicJsonDocument doc(1024);
            deserializeJson(doc, (char*)payload);
            
            if (doc["type"] == "new_message") {
                String username = doc["username"];
                String content = doc["content"];
                chatMessages.push_back(username + ": " + content);
                
                saveChatMessageToSD(username, content, "text");
                
                if (chatMessages.size() > 30) {
                    chatMessages.erase(chatMessages.begin());
                }
                
                if (currentMode == MODE_CHAT) {
                    showChatScreen();
                }
            }
            break;
        }
    }
}

void showError(String message) {
    tft.fillScreen(TFT_RED);
    tft.setTextColor(TFT_WHITE);
    tft.setCursor(10, 50);
    tft.println(message);
}

void showStatus(String message) {
    tft.fillScreen(TFT_BLACK);
    tft.setTextColor(TFT_CYAN);
    tft.setCursor(10, 100);
    tft.println(message);
}

void showMainMenu() {
    tft.fillScreen(TFT_BLACK);
    tft.setTextColor(TFT_CYAN);
    tft.setCursor(20, 20);
    tft.setTextSize(2);
    tft.println("T-Embed");
    tft.println("Chat");
    
    tft.setTextSize(1);
    tft.setTextColor(TFT_WHITE);
    
    const char* menuItems[] = {
        "1. Чат",
        "2. Блог", 
        "3. Сервер",
        "4. Поддержка"
    };
    
    for (int i = 0; i < 4; i++) {
        tft.setCursor(10, 80 + (i * 20));
        
        if (i == menuSelection) {
            tft.setTextColor(TFT_BLACK);
            tft.fillRect(5, 75 + (i * 20), 160, 18, TFT_WHITE);
        } else {
            tft.setTextColor(TFT_WHITE);
        }
        
        tft.println(menuItems[i]);
    }
    
    tft.setTextColor(TFT_YELLOW);
    tft.setCursor(10, 200);
    tft.println("Энкодер: Навигация");
    tft.setCursor(10, 220);
    tft.println("Кнопка: Выбор");
    tft.setCursor(10, 240);
    tft.println("Боковая: Режим");
}

void showChatScreen() {
    tft.fillScreen(TFT_BLACK);
    tft.setTextColor(TFT_CYAN);
    tft.setCursor(10, 10);
    tft.println("=== ЧАТ ===");
    
    // Показываем сообщения
    int startY = 30;
    int maxMessages = min(10, (int)chatMessages.size());
    int startIndex = max(0, (int)chatMessages.size() - maxMessages - scrollPosition);
    
    for (int i = startIndex; i < min(startIndex + 10, (int)chatMessages.size()); i++) {
        tft.setCursor(5, startY + (i - startIndex) * 15);
        tft.setTextColor(TFT_WHITE);
        
        String msg = chatMessages[i];
        if (msg.length() > 20) {
            msg = msg.substring(0, 17) + "...";
        }
        tft.println(msg);
    }
    
    tft.setTextColor(TFT_GREEN);
    tft.setCursor(5, 280);
    tft.println("Энкодер: Прокрутка");
}

void showBlogScreen() {
    tft.fillScreen(TFT_BLACK);
    tft.setTextColor(TFT_MAGENTA);
    tft.setCursor(10, 10);
    tft.println("=== БЛОГ ===");
    
    if (blogPosts.empty()) {
        tft.setCursor(10, 50);
        tft.setTextColor(TFT_YELLOW);
        tft.println("Постов нет");
    } else {
        int startY = 30;
        int maxPosts = min(8, (int)blogPosts.size());
        
        for (int i = 0; i < maxPosts; i++) {
            tft.setCursor(5, startY + (i * 20));
            tft.setTextColor(TFT_WHITE);
            
            String post = blogPosts[i];
            if (post.length() > 18) {
                post = post.substring(0, 15) + "...";
            }
            tft.println(post);
        }
    }
}

void showServerScreen() {
    tft.fillScreen(TFT_BLACK);
    tft.setTextColor(TFT_GREEN);
    tft.setCursor(10, 10);
    tft.println("=== СЕРВЕР ===");
    
    tft.setTextColor(TFT_WHITE);
    tft.setCursor(5, 40);
    
    if (isServerConnected) {
        tft.printf("IP: %s\n", mainServerIP.c_str());
        tft.setCursor(5, 60);
        tft.println("Статус: Подключен");
        
        // Показываем статистику SD карты
        uint64_t cardSize = SD.cardSize() / (1024 * 1024);
        uint64_t usedSize = SD.usedBytes() / (1024 * 1024);
        
        tft.setCursor(5, 100);
        tft.printf("SD: %lluМБ\n", cardSize);
        tft.setCursor(5, 120);
        tft.printf("Занято: %lluМБ\n", usedSize);
        
        float usage = (float)usedSize / cardSize * 100.0;
        tft.setCursor(5, 140);
        tft.printf("Использ: %.1f%%\n", usage);
    } else {
        tft.println("Автономный режим");
        tft.setCursor(5, 60);
        tft.println("Поиск серверов...");
    }
}

void showSupportScreen() {
    tft.fillScreen(TFT_BLACK);
    tft.setTextColor(TFT_ORANGE);
    tft.setCursor(10, 10);
    tft.println("=== ПОДДЕРЖКА ===");
    
    tft.setTextColor(TFT_WHITE);
    tft.setCursor(10, 40);
    tft.println("Отправка сообщения");
    tft.println("администратору");
    
    if (isInputMode) {
        tft.setCursor(5, 80);
        tft.setTextColor(TFT_GREEN);
        tft.println("Текст:");
        tft.setCursor(5, 100);
        tft.println(inputText + "_");
        
        tft.setCursor(5, 250);
        tft.setTextColor(TFT_YELLOW);
        tft.println("Кнопка: Отправить");
    } else {
        tft.setCursor(10, 80);
        tft.setTextColor(TFT_YELLOW);
        tft.println("Кнопка: Написать");
    }
}

void handleEncoder() {
    long newPosition = encoder.read() / 4; // Делим на 4 для стабильности
    
    if (newPosition != encoderPosition) {
        int delta = newPosition - encoderPosition;
        encoderPosition = newPosition;
        
        if (!isLoggedIn) {
            // Навигация по главному меню
            menuSelection += delta;
            if (menuSelection < 0) menuSelection = 3;
            if (menuSelection > 3) menuSelection = 0;
            showMainMenu();
        } else {
            // Навигация в активном режиме
            switch (currentMode) {
                case MODE_CHAT:
                    scrollPosition += delta;
                    if (scrollPosition < 0) scrollPosition = 0;
                    showChatScreen();
                    break;
                case MODE_BLOG:
                    // Прокрутка блога
                    showBlogScreen();
                    break;
            }
        }
    }
}

void handleButtons() {
    // Главная кнопка энкодера
    if (digitalRead(ENCODER_BUTTON) == LOW && millis() - lastButtonPress > 300) {
        lastButtonPress = millis();
        
        if (!isLoggedIn) {
            // Выбор режима из главного меню
            switch (menuSelection) {
                case 0:
                    currentMode = MODE_CHAT;
                    loadChatHistory();
                    showChatScreen();
                    break;
                case 1:
                    currentMode = MODE_BLOG;
                    loadBlogPosts();
                    showBlogScreen();
                    break;
                case 2:
                    currentMode = MODE_SERVER;
                    showServerScreen();
                    break;
                case 3:
                    currentMode = MODE_SUPPORT;
                    showSupportScreen();
                    break;
            }
            isLoggedIn = true; // Упрощено для демо
        } else {
            // Действия в активном режиме
            if (currentMode == MODE_SUPPORT) {
                if (!isInputMode) {
                    isInputMode = true;
                    inputText = "";
                    showSupportScreen();
                } else {
                    // Отправляем сообщение
                    sendSupportMessage(inputText);
                    isInputMode = false;
                    inputText = "";
                    showSupportScreen();
                }
            }
        }
    }
    
    // Боковая кнопка - переключение режимов
    if (digitalRead(SIDE_BUTTON) == LOW && millis() - lastButtonPress > 300) {
        lastButtonPress = millis();
        
        if (isLoggedIn) {
            // Циклическое переключение режимов
            switch (currentMode) {
                case MODE_CHAT:
                    currentMode = MODE_BLOG;
                    loadBlogPosts();
                    showBlogScreen();
                    break;
                case MODE_BLOG:
                    currentMode = MODE_SERVER;
                    showServerScreen();
                    break;
                case MODE_SERVER:
                    currentMode = MODE_SUPPORT;
                    showSupportScreen();
                    break;
                case MODE_SUPPORT:
                    currentMode = MODE_CHAT;
                    loadChatHistory();
                    showChatScreen();
                    break;
            }
        }
    }
}

void sendSupportMessage(String message) {
    if (isServerConnected) {
        // HTTP запрос
        HTTPClient http;
        http.begin("http://" + mainServerIP + "/api/sendSupportMessage");
        http.addHeader("Content-Type", "application/json");
        
        DynamicJsonDocument doc(512);
        doc["username"] = currentUser;
        doc["message"] = message;
        
        String jsonString;
        serializeJson(doc, jsonString);
        
        http.POST(jsonString);
        http.end();
    }
    
    // Сохраняем на SD карту
    saveSupportMessageToSD(currentUser, message);
    
    // Показываем подтверждение
    tft.fillScreen(TFT_GREEN);
    tft.setTextColor(TFT_WHITE);
    tft.setCursor(20, 100);
    tft.println("Отправлено!");
    delay(1000);
}

void loadChatHistory() {
    if (isServerConnected) {
        // Загружаем с сервера
        HTTPClient http;
        http.begin("http://" + mainServerIP + "/api/getChatHistory");
        
        int responseCode = http.GET();
        if (responseCode == 200) {
            String response = http.getString();
            DynamicJsonDocument doc(4096);
            deserializeJson(doc, response);
            
            JsonArray messages = doc["messages"];
            chatMessages.clear();
            
            for (JsonObject message : messages) {
                String username = message["username"];
                String content = message["content"];
                chatMessages.push_back(username + ": " + content);
            }
        }
        
        http.end();
    } else {
        // Загружаем из SD карты
        loadChatFromSD();
    }
}

void loadBlogPosts() {
    if (isServerConnected) {
        HTTPClient http;
        http.begin("http://" + mainServerIP + "/api/getBlogPosts");
        
        int responseCode = http.GET();
        if (responseCode == 200) {
            String response = http.getString();
            DynamicJsonDocument doc(4096);
            deserializeJson(doc, response);
            
            JsonArray posts = doc["posts"];
            blogPosts.clear();
            
            for (JsonObject post : posts) {
                String title = post["title"];
                String author = post["author"];
                blogPosts.push_back(title + " - " + author);
            }
        }
        
        http.end();
    } else {
        loadBlogFromSD();
    }
}

void saveChatMessageToSD(String username, String content, String messageType) {
    if (!sdCardReady) return;
    
    File chatFile = SD.open("/root/chat/messages.txt", FILE_APPEND);
    if (chatFile) {
        String timestamp = String(millis());
        String line = timestamp + "," + username + "," + messageType + "," + content;
        chatFile.println(line);
        chatFile.close();
    }
}

void saveSupportMessageToSD(String username, String message) {
    if (!sdCardReady) return;
    
    File supportFile = SD.open("/root/support/tickets.txt", FILE_APPEND);
    if (supportFile) {
        String timestamp = String(millis());
        String line = timestamp + "," + username + "," + message;
        supportFile.println(line);
        supportFile.close();
    }
}

void loadChatFromSD() {
    if (!sdCardReady) return;
    
    chatMessages.clear();
    
    if (SD.exists("/root/chat/messages.txt")) {
        File chatFile = SD.open("/root/chat/messages.txt");
        if (chatFile) {
            while (chatFile.available() && chatMessages.size() < 30) {
                String line = chatFile.readStringUntil('\n');
                line.trim();
                
                if (line.length() > 0 && !line.startsWith("#")) {
                    // Парсим сообщение
                    int firstComma = line.indexOf(',');
                    int secondComma = line.indexOf(',', firstComma + 1);
                    int thirdComma = line.indexOf(',', secondComma + 1);
                    
                    if (thirdComma > 0) {
                        String username = line.substring(firstComma + 1, secondComma);
                        String content = line.substring(thirdComma + 1);
                        chatMessages.push_back(username + ": " + content);
                    }
                }
            }
            chatFile.close();
        }
    }
}

void loadBlogFromSD() {
    // Аналогично loadChatFromSD, но для блога
    blogPosts.clear();
}

void loop() {
    // Обработка WebSocket
    if (isServerConnected) {
        webSocket.loop();
    }
    
    // Обработка пользовательского ввода
    handleEncoder();
    handleButtons();
    
    // Периодические задачи
    static unsigned long lastUpdate = 0;
    if (millis() - lastUpdate > 5000) {
        lastUpdate = millis();
        
        // Проверяем соединение
        if (!isServerConnected && WiFi.status() != WL_CONNECTED) {
            searchForServer();
        }
    }
    
    delay(50);
}